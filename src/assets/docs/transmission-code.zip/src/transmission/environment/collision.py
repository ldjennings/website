"""
FCL collision checker for the SM-465 mainshaft removal problem.
"""

import numpy as np
import fcl

from transmission.aliases import ShaftPose
from transmission.state_utils import rotation_from_spherical, interpolate_pose
from transmission.environment.meshes import (
    build_mainshaft_mesh, build_countershaft_mesh, build_enclosure_mesh,
)


def _mesh_to_fcl(mesh) -> fcl.BVHModel:
    verts = np.array(mesh.vertices, dtype=np.float64)
    tris  = np.array(mesh.faces,    dtype=np.int32)
    model = fcl.BVHModel()
    model.beginModel(len(tris), len(verts))
    model.addSubModel(verts, tris)
    model.endModel()
    return model


class TransmissionCollisionChecker:
    """FCL-based collision checker for mainshaft removal."""

    def __init__(self):
        print("Building transmission geometry...")

        self.mainshaft_mesh    = build_mainshaft_mesh()
        self.countershaft_mesh = build_countershaft_mesh()
        self.enclosure_mesh    = build_enclosure_mesh()

        self._ms_fcl        = _mesh_to_fcl(self.mainshaft_mesh)
        self._cs_fcl        = _mesh_to_fcl(self.countershaft_mesh)
        self._enclosure_fcl = _mesh_to_fcl(self.enclosure_mesh)

        identity = fcl.Transform(np.eye(3), np.zeros(3))
        self._cs_obj        = fcl.CollisionObject(self._cs_fcl, identity)
        self._enclosure_obj = fcl.CollisionObject(self._enclosure_fcl, identity)

        print(f"  Mainshaft:    {len(self.mainshaft_mesh.faces)} triangles")
        print(f"  Countershaft: {len(self.countershaft_mesh.faces)} triangles")
        print(f"  Enclosure:    {len(self.enclosure_mesh.faces)} triangles")
        print("Ready.")

    def check_collision(self, pose: ShaftPose) -> bool:
        """Return True if the mainshaft at this pose is in collision."""
        x, y, z, theta, phi = pose
        tf     = fcl.Transform(rotation_from_spherical(theta, phi), np.array([x, y, z]))
        ms_obj = fcl.CollisionObject(self._ms_fcl, tf)
        req    = fcl.CollisionRequest()

        res = fcl.CollisionResult()
        fcl.collide(ms_obj, self._cs_obj, req, res)
        if res.is_collision:
            return True

        res = fcl.CollisionResult()
        fcl.collide(ms_obj, self._enclosure_obj, req, res)
        return res.is_collision

    def check_collision_detailed(self, pose: ShaftPose) -> dict:
        """Collision check with per-obstacle breakdown."""
        x, y, z, theta, phi = pose
        tf     = fcl.Transform(rotation_from_spherical(theta, phi), np.array([x, y, z]))
        ms_obj = fcl.CollisionObject(self._ms_fcl, tf)
        req    = fcl.CollisionRequest(num_max_contacts=10)

        res_cs  = fcl.CollisionResult()
        res_enc = fcl.CollisionResult()
        fcl.collide(ms_obj, self._cs_obj,        req, res_cs)
        fcl.collide(ms_obj, self._enclosure_obj, req, res_enc)

        return {
            'collision':       res_cs.is_collision or res_enc.is_collision,
            'vs_countershaft': res_cs.is_collision,
            'vs_enclosure':    res_enc.is_collision,
        }


    def check_path_segment(self,
                           p1: ShaftPose, p2: ShaftPose,
                           min_checks: int = 5) -> bool:
        """Return True if the straight-line segment from p1 to p2 is collision-free.

        Scales the number of samples with Euclidean position distance (~1 per 5 mm),
        floored at min_checks.
        """
        pos_dist = np.linalg.norm(np.subtract(p1[:3], p2[:3]))
        n        = max(min_checks, int(pos_dist / 5))
        for i in range(n + 1):
            if self.check_collision(interpolate_pose(p1, p2, i / n)):
                return False
        return True
