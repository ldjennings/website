# SM-465 transmission geometry parameters (from scad_files/transmission.scad)

import math

# =============================================================================
# Component thicknesses (shared by both shafts)
# =============================================================================
GEAR_THICKNESS = 25.0
COLLAR_THICKNESS = 30.0
SYNCRO_THICKNESS = 8.0

# =============================================================================
# Mainshaft gear, collar, and syncro radii
# All values are tip (outer) radii. Gear cylinders are built at full tip radius
# so they encapsulate the real gear geometry — see geometry construction note.
# =============================================================================
SYNCRO12_RADIUS = 48.0
SYNCRO34_RADIUS = 45.0
GEAR1_RADIUS = 65.0
GEAR2_RADIUS = 53.0
GEAR3_RADIUS = 45.0
GEAR_REV_RADIUS = 60.0
COLLAR12_RADIUS = 60.0
COLLAR34_RADIUS = 60.0

# =============================================================================
# Shaft dimensions
# =============================================================================
SHAFT_RADIUS = 18.0
MAINSHAFT_LENGTH = 330.0

# =============================================================================
# Enclosure dimensions and bearing positions
# =============================================================================
ENCLOSURE_THICKNESS = 25.0
ENCLOSURE_LENGTH = 280.0
ENCLOSURE_WIDTH = 210.0
ENCLOSURE_HEIGHT = 300.0

BEARING_RADIUS = 40.0
MAINSHAFT_BEARING_HEIGHT = 215.0  # mainshaft bearing centerline above enclosure base
CS_BEARING_HEIGHT = 100.0         # countershaft bearing centerline above enclosure base

# =============================================================================
# Countershaft geometry
# =============================================================================
# Center-to-center distance between the two shafts
SHAFT_CENTER_OFFSET = MAINSHAFT_BEARING_HEIGHT - CS_BEARING_HEIGHT  # 115

COUNTERSHAFT_LENGTH = ENCLOSURE_LENGTH + 2 * ENCLOSURE_THICKNESS  # 330

# Countershaft gear radii mesh with mainshaft gears; derived from center-to-center offset
CS_GEAR1_RADIUS = SHAFT_CENTER_OFFSET - GEAR1_RADIUS
CS_GEAR2_RADIUS = SHAFT_CENTER_OFFSET - GEAR2_RADIUS
CS_GEAR3_RADIUS = SHAFT_CENTER_OFFSET - GEAR3_RADIUS
CS_GEAR_REV_RADIUS = SHAFT_CENTER_OFFSET - GEAR_REV_RADIUS - 15
CS_COUNTERGEAR_RADIUS = 70.0

# =============================================================================
# Mesh resolution
# =============================================================================
N_CYL_SECTIONS = 16  # triangle count per cylinder cross-section

# =============================================================================
# Problem definition: start and goal poses  (x, y, z, theta, phi)
# =============================================================================
# Assembled position: shaft axis along +X, centroid nominally at (80, 0, 227.5).
# The +5 mm Z offset gives clearance between the tip-radius gear cylinders:
# at the nominal bearing height the meshing pairs (e.g. gear1 r=65, CS r=50)
# sum to exactly the 115 mm shaft centre-to-centre distance — tangent in the
# collision mesh. The planner starts with the shaft already raised by this amount.
INITIAL_POSE = (
    -85.0 + MAINSHAFT_LENGTH / 2,                               # x = 80
    0.0,                                                        # y
    MAINSHAFT_BEARING_HEIGHT + 0.5 * ENCLOSURE_THICKNESS + 15,  # z = 232.5
    math.pi / 2,                                                # theta — shaft along +X
    0.0,                                                        # phi
)

# Resting on workbench clear of the enclosure, upright on largest gear
GOAL_POSE = (
    0.0,                 # x
    250.0,               # y
    GEAR1_RADIUS + 10,   # z — resting on largest gear with small clearance
    math.pi / 2,         # theta
    0.0,                 # phi
)
