"""
Simulation constants for the Wildfire assignment.

All tunable parameters live here so implementation files stay clean.
"""

import math

# ── Field ────────────────────────────────────────────────────────────────
FIELD_SIZE      = 250                       # meters, square field
CELL_SIZE       = 5                         # meters per grid cell
GRID_SIZE       = FIELD_SIZE // CELL_SIZE   # 50 cells per side

# ── Display ──────────────────────────────────────────────────────────────
VIRTUAL_SIZE     = (800, 800)
METERS_TO_PIXELS = min(
    VIRTUAL_SIZE[0] / FIELD_SIZE,
    VIRTUAL_SIZE[1] / FIELD_SIZE,
)

# ── Obstacle generation ──────────────────────────────────────────────────
OBSTACLE_COVERAGE = 0.10  # % of cells filled by tetrominoes

# ── Firetruck (Mercedes Unimog) ──────────────────────────────────────────
TRUCK_WIDTH           = 2.2    # meters
TRUCK_LENGTH          = 4.9    # meters
TRUCK_WHEELBASE       = 3.0    # meters
TRUCK_MIN_TURN_RADIUS = 13.0   # meters
TRUCK_MAX_VELOCITY    = 10.0   # m/s
TRUCK_MAX_STEER       = math.atan(TRUCK_WHEELBASE / TRUCK_MIN_TURN_RADIUS)

# ── Wumpus ───────────────────────────────────────────────────────────────
WUMPUS_MOVE_INTERVAL = 2.6  # seconds between grid cell moves

# ── Fire mechanics ───────────────────────────────────────────────────────
FIRE_SPREAD_TIME   = 10.0   # seconds before a burning obstacle spreads fire
FIRE_SPREAD_RADIUS = 30.0   # meters, radius of fire spread
BURN_DURATION      = 60.0   # seconds of burning before obstacle is fully burned
EXTINGUISH_TIME    = 5.0    # seconds the truck must remain near to extinguish
EXTINGUISH_RADIUS  = 10.0   # meters, max distance from obstacle center to extinguish

# ── Simulation ───────────────────────────────────────────────────────────
SIM_DURATION   = 3600   # seconds per run
SIM_DT         = 0.1    # physics timestep (seconds)
TRUCK_TARGET_CHECK_INTERVAL = 1.0  # seconds between target re-evaluation
TRUCK_MAX_QUERY_ATTEMPTS    = 3    # max fires to try planning to per replan tick
NUM_ITERATIONS = 5      # runs per scenario

# ── PRM parameters ───────────────────────────────────────────────────────
PRM_NUM_SAMPLES    = 500   # roadmap samples
PRM_K_NEIGHBORS    = 15     # edges per node (connect to k nearest)
PRM_MAX_EDGE_LEN   = 50.0   # meters, max straight-line edge length

# ── Colors ───────────────────────────────────────────────────────────────
BLACK      = (0, 0, 0)
WHITE      = (255, 255, 255)
GREEN      = (0, 150, 0)
DARK_GREEN = (0, 100, 0)
RED        = (220, 30, 30)
ORANGE     = (255, 140, 0)
BLUE       = (30, 100, 200)
LIGHT_BLUE = (100, 180, 255)
YELLOW     = (255, 255, 0)
GRAY       = (150, 150, 150)
DARK_GRAY  = (60, 60, 60)
BROWN      = (80, 40, 0)
PURPLE     = (128, 0, 128)
