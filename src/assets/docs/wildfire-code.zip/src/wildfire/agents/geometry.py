"""
Shapely geometry construction for the firetruck collision footprint.

Base shapes are built once and cached. Per-state footprint calls only
rotate + translate (or use the heading cache for approximate checks).

Adapted from valet's bots/geometry.py to match the current API.
"""

import math
from typing import TypeAlias

from shapely.affinity import rotate, translate
from shapely.geometry import box
from shapely.geometry.base import BaseGeometry

from wildfire.aliases import BoundingBox


# ── base shape constructors (call once, cache the result) ────────────────

def make_axle_rect_base(wheelbase: float, length: float, width: float) -> BaseGeometry:
    """Rectangle with rear axle at origin (for Ackermann bots)."""
    rect = box(-length / 2, -width / 2, length / 2, width / 2)
    rear_overhang = length - wheelbase
    offset = (length / 2) - rear_overhang
    return translate(rect, xoff=offset)


# ── heading cache ─────────────────────────────────────────────────────────

HEADING_CACHE_SIZE = 72  # one slot per 5 degrees

CachedShape: TypeAlias = tuple[BaseGeometry, BoundingBox]

def build_heading_cache(base: BaseGeometry) -> list[CachedShape]:
    """Pre-rotate base shape at HEADING_CACHE_SIZE evenly-spaced headings, storing bounds alongside."""
    result = []
    for i in range(HEADING_CACHE_SIZE):
        geom = rotate(base, math.degrees(i * 2 * math.pi / HEADING_CACHE_SIZE), origin=(0, 0))
        result.append((geom, geom.bounds))
    return result


def lookup_cached(cache: list[CachedShape], heading_rad: float) -> CachedShape:
    """Find the closest pre-rotated (geom, bounds) pair for a given heading."""
    idx = round(heading_rad % (2 * math.pi) / (2 * math.pi) * HEADING_CACHE_SIZE) % HEADING_CACHE_SIZE
    return cache[idx]


# ── per-state placement ──────────────────────────────────────────────────

def place(base: BaseGeometry, x: float, y: float, angle_rad: float) -> BaseGeometry:
    """Rotate base shape by angle_rad about origin, then translate to (x, y)."""
    return translate(rotate(base, math.degrees(angle_rad), origin=(0, 0)), xoff=x, yoff=y)

