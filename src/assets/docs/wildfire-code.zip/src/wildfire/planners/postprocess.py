"""
Path postprocessing for the PRM planner.
"""

import numpy as np

from wildfire.agents import TruckState, Firetruck
from wildfire.environment import WildfireEnvironment


def path_collision_free(env: WildfireEnvironment, truck: Firetruck, path: list[TruckState], step: int = 4) -> bool:
    """Check every Nth state along path using the truck's approximate footprint."""
    for i in range(0, len(path), step):
        if not env.is_valid_state(truck.footprint(path[i], approximate=True)):
            return False
    # always check last state
    if not env.is_valid_state(truck.footprint(path[-1], approximate=False)):
        return False
    return True


def smooth_path(
    path: list[TruckState],
    env: WildfireEnvironment,
    truck: Firetruck,
    rng: np.random.Generator,
    max_iterations: int = 80,
    stall_limit: int = 15,
) -> list[TruckState]:
    """
    Probabilistic path shortcutting: pick two random states, attempt a
    direct connection, and replace the span if it's collision-free and
    shorter. Stops early after stall_limit consecutive failures.
    """
    path = list(path)
    consecutive_failures = 0

    for _ in range(max_iterations):
        if len(path) < 4:
            break

        a = int(rng.integers(0, len(path) - 2))
        b = int(rng.integers(a + 2, len(path)))

        sa = path[a]
        sb = path[b]
        start_pose = (sa.rear_axle_x, sa.rear_axle_y, sa.heading_rad)
        end_pose   = (sb.rear_axle_x, sb.rear_axle_y, sb.heading_rad)

        shortcut = truck.generate_trajectory(start_pose, end_pose, 0.5)
        if shortcut is None or len(shortcut) >= (b - a + 1):
            consecutive_failures += 1
            if consecutive_failures >= stall_limit:
                break
            continue

        if path_collision_free(env, truck, shortcut):
            path = path[:a] + shortcut + path[b + 1:]
            consecutive_failures = 0
        else:
            consecutive_failures += 1
            if consecutive_failures >= stall_limit:
                break

    return path
