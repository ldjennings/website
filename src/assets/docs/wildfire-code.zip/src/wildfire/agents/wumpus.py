"""
Wumpus agent: grid-based movement with A* planning.

The Wumpus navigates a grid, moving to cells adjacent to intact
obstacles and igniting them.  It can perceive the firetruck but
does not interact with it directly.
"""

import wildfire.config as cfg
from .state import WumpusState
from wildfire.planners import grid_astar
from wildfire.aliases import GridCell, GridPath, WorldPos
from wildfire.utils import euclidean_distance
from wildfire.environment import WildfireEnvironment


class Wumpus:

    def __init__(self, start_row: int, start_col: int) -> None:
        self.state = WumpusState(start_row, start_col)
        self._move_timer: float = 0.0
        self._current_path: GridPath | None = None
        self._path_index: int = 0
        self._target: GridCell | None = None

    # ── update ───────────────────────────────────────────────────────────

    def update(self, env: WildfireEnvironment, dt: float, current_time: float,
               truck_pos: WorldPos | None = None) -> None:
        if not self._tick(dt):
            return

        if self._needs_new_target():
            self._replan(env, truck_pos)
            return

        if self._at_target():
            self._ignite_and_replan(env, current_time, truck_pos)
            return

        self._advance_or_replan(env, truck_pos)

    # ── movement ─────────────────────────────────────────────────────────

    def _tick(self, dt: float) -> bool:
        self._move_timer += dt
        if self._move_timer < cfg.WUMPUS_MOVE_INTERVAL:
            return False
        self._move_timer = 0.0
        return True

    def _advance_or_replan(self, env: WildfireEnvironment, truck_pos: WorldPos | None) -> None:
        assert self._target is not None

        target_already_lit = env.obstacle_map[self._target] not in env.get_intact()
        path_available = self._current_path is not None and self._path_index < len(self._current_path)

        if path_available and not target_already_lit:
            assert self._current_path is not None
            nr, nc = self._current_path[self._path_index]
            if env.is_cell_free(nr, nc):
                self.state = WumpusState(nr, nc)
            self._path_index += 1
        else:
            self._replan(env, truck_pos)

    def _ignite_and_replan(self, env: WildfireEnvironment, current_time: float,
                           truck_pos: WorldPos | None) -> None:
        assert self._target is not None
        env.ignite(self._target[0], self._target[1], current_time)
        self._clear_target()
        self._replan(env, truck_pos)

    # ── planning ─────────────────────────────────────────────────────────

    def _replan(self, env: WildfireEnvironment, truck_pos: WorldPos | None) -> None:
        target = self._select_target(env, truck_pos)
        if target is None:
            self._clear_target()
            return

        goal = self._approach_cell(env, target)
        if goal is None:
            self._clear_target()
            return

        self._target = target
        start = (self.state.grid_row, self.state.grid_col)
        self._current_path = grid_astar(env, start, goal)
        self._path_index = 0

    def _select_target(self, env: WildfireEnvironment,
                       truck_pos: WorldPos | None) -> GridCell | None:
        """Pick the intact obstacle that maximizes distance from the truck and is reasonably close to the wumpus."""
        intact = env.get_intact()
        if not intact:
            return None

        wpos = self.state.world_pos
        if truck_pos is not None:
            best = max(intact, key=lambda o:
                euclidean_distance(truck_pos, o.center)
                - 0.5 * euclidean_distance(wpos, o.center))
        else:
            best = min(intact, key=lambda o: euclidean_distance(wpos, o.center))

        return (best.grid_row, best.grid_col)

    def _approach_cell(self, env: WildfireEnvironment,
                       target: GridCell) -> GridCell | None:
        """Return the free neighbor of target closest to the wumpus."""
        candidates = env.get_free_neighbors(target)
        if not candidates:
            return None
        return min(candidates, key=lambda c:
            abs(c[0] - self.state.grid_row) + abs(c[1] - self.state.grid_col))

    # ── helpers ──────────────────────────────────────────────────────────

    def _needs_new_target(self) -> bool:
        return self._target is None or self._current_path is None

    def _at_target(self) -> bool:
        assert self._target is not None
        return max(abs(self.state.grid_row - self._target[0]),
                   abs(self.state.grid_col - self._target[1])) == 1

    def _clear_target(self) -> None:
        self._target = None
        self._current_path = None
