"""
Firetruck agent: Ackermann kinematics, footprint, and behavior.

The firetruck is a car-like robot (Mercedes Unimog) that uses a PRM
planner with Reeds-Shepp local connections to navigate. Paths are
dense sequences of TruckStates played back at the truck's velocity.
"""


import reeds_shepp

import wildfire.config as cfg
from .state import TruckState
from .geometry import make_axle_rect_base, build_heading_cache, lookup_cached, place
from wildfire.aliases import Footprint, GridCell, Pose, WorldPos
from wildfire.utils import euclidean_distance
from wildfire.environment import WildfireEnvironment


# ── helpers ───────────────────────────────────────────────────────────────────

def is_valid_pose(env: WildfireEnvironment, truck: "Firetruck", state: TruckState) -> bool:
    """True if the truck's footprint at state is inside bounds and collision-free."""
    return env.is_valid_state(truck.footprint(state, approximate=True))


# ── Firetruck ─────────────────────────────────────────────────────────────────

class Firetruck:

    # ── construction ─────────────────────────────────────────────────────

    def __init__(self, start_x: float, start_y: float, heading: float = 0.0) -> None:
        self.state = TruckState(start_x, start_y, heading)

        self._max_steer      = cfg.TRUCK_MAX_STEER
        self._max_velocity   = cfg.TRUCK_MAX_VELOCITY
        self._turning_radius = cfg.TRUCK_MIN_TURN_RADIUS

        # base rectangle at origin, rear axle at (0,0)
        self._base = make_axle_rect_base(cfg.TRUCK_WHEELBASE, cfg.TRUCK_LENGTH, cfg.TRUCK_WIDTH)
        self._cache = build_heading_cache(self._base)

        # path-following bookkeeping
        self.current_path: list[TruckState] | None = None
        self.path_index: int = 0

        # extinguishing bookkeeping
        self._extinguish_timer: float = 0.0
        self.extinguish_target: GridCell | None = None

    # ── geometry ─────────────────────────────────────────────────────────

    def footprint(self, state: TruckState | None = None, approximate: bool = False) -> Footprint:
        """
        Collision geometry at the given (or current) state.

        If approximate=True, geometry is pre-rotated but NOT translated — offset is (x, y).
        If approximate=False, geometry is fully placed — offset is (0, 0).
        """
        if state is None:
            state = self.state
        x, y, h = state
        if approximate:
            geom, bounds = lookup_cached(self._cache, h)
            return [(x, y, geom, bounds)]
        g = place(self._base, x, y, h)
        return [(0.0, 0.0, g, g.bounds)]

    # ── trajectory generation ────────────────────────────────────────────

    def trajectory_length(self, start: Pose, goal: Pose) -> float:
        return reeds_shepp.path_length(start, goal, self._turning_radius)

    def generate_trajectory(self, start: Pose, goal: Pose, resolution: float = 0.5) -> list[TruckState] | None:
        """Generate a kinematically feasible path between two poses. Returns None if no path exists."""
        raw = reeds_shepp.path_sample(start, goal, self._turning_radius, resolution)
        if not raw:
            return None
        states = [TruckState(r[0], r[1], r[2]) for r in raw]
        goal_state = TruckState(*goal)
        last = states[-1]
        if euclidean_distance((last.rear_axle_x, last.rear_axle_y),
                              (goal_state.rear_axle_x, goal_state.rear_axle_y)) < 1e-9:
            states[-1] = goal_state  # same position: snap heading only
        else:
            states.append(goal_state)
        return states

    # ── path following ───────────────────────────────────────────────────

    def set_path(self, path: list[TruckState]) -> None:
        """Load a new dense TruckState path to follow."""
        self.current_path = path
        self.path_index = 0

    def follow_path(self, dt: float) -> None:
        """Advance along current_path by velocity * dt meters. Returns True while still following."""
        if not self.has_path():
            return

        distance_remaining = self._max_velocity * dt
        while distance_remaining > 0 and not self._at_end():
            distance_remaining = self._step(distance_remaining)

        if self._at_end():
            self._finish_path()


    def has_path(self) -> bool:
        return self.current_path is not None and self.path_index < len(self.current_path)

    def _at_end(self) -> bool:
        return self.current_path is None or self.path_index >= len(self.current_path) - 1

    def _finish_path(self) -> None:
        assert self.current_path is not None
        self.state = self.current_path[-1]
        self.current_path = None

    def _step(self, distance_remaining: float) -> float:
        """
        Attempt to traverse the current path segment using distance_remaining meters.
        If the segment fits, advance to the next waypoint and return the leftover distance.
        If not, interpolate to the reachable point along the segment and return 0.
        """
        assert self.current_path is not None

        cur = self.current_path[self.path_index]
        nxt = self.current_path[self.path_index + 1]

        seg_len = euclidean_distance((cur.rear_axle_x, cur.rear_axle_y),
                                     (nxt.rear_axle_x, nxt.rear_axle_y))

        if seg_len < 1e-9:
            raise ValueError(
                f"Path contains a zero-length segment at index {self.path_index}"
                f"Ackermann kinematics cannot produce in-place rotation\n"
                f"  cur: ({cur.rear_axle_x:.4f}, {cur.rear_axle_y:.4f}, heading={cur.heading_rad:.4f})\n"
                f"  nxt: ({nxt.rear_axle_x:.4f}, {nxt.rear_axle_y:.4f}, heading={nxt.heading_rad:.4f})"
            )

        if distance_remaining >= seg_len:
            self.path_index += 1
            self.state = nxt
            return distance_remaining - seg_len
        else:
            self.state = cur.interpolate(nxt, distance_remaining / seg_len)
            return 0.0

    # ── extinguishing ────────────────────────────────────────────────────

    def try_extinguish(self, env: WildfireEnvironment, dt: float) -> bool:
        """Attempt to extinguish the nearest burning obstacle. Returns True while actively working."""
        target = self._nearest_burning_in_range(env)
        if target is None:
            self._reset_extinguish_state()
            return False

        self._accumulate_extinguish_time(target, dt)

        if self._extinguish_timer >= cfg.EXTINGUISH_TIME:
            self._complete_extinguish(env, target)

        return True

    def _nearest_burning_in_range(self, env: WildfireEnvironment) -> GridCell | None:
        """Return the grid key of the closest burning obstacle within extinguish range, or None."""
        burning = env.get_burning()

        if not burning:
            return None

        pos = (self.state.rear_axle_x, self.state.rear_axle_y)
        closest = min(burning, key=lambda o: euclidean_distance(pos, o.center))

        if euclidean_distance(pos, closest.center) <= cfg.EXTINGUISH_RADIUS:
            return (closest.grid_row, closest.grid_col)
        return None

    def _accumulate_extinguish_time(self, target: GridCell, dt: float) -> None:
        """Accumulate time on target, resetting the timer if the target changed."""
        if self.extinguish_target == target:
            self._extinguish_timer += dt
        else:
            self.extinguish_target = target
            self._extinguish_timer = dt

    def _complete_extinguish(self, env: WildfireEnvironment, target: GridCell) -> None:
        env.extinguish(target[0], target[1])
        self._reset_extinguish_state()

    def _reset_extinguish_state(self) -> None:
        self._extinguish_timer = 0.0
        self.extinguish_target = None

    # ── target selection ─────────────────────────────────────────────────

    def choose_targets(self, env: WildfireEnvironment, max_candidates: int = 5) -> list[tuple[WorldPos, WorldPos]]:
        """
        Return reachable approach points for the nearest max_candidates burning
        obstacles, sorted nearest-first. Each entry is (goal_xy, fire_center).
        The caller tries each in order, using the first one the planner can connect to.
        """
        burning = env.get_burning()
        if not burning:
            return []

        pos = (self.state.rear_axle_x, self.state.rear_axle_y)
        nearest = sorted(burning, key=lambda o: euclidean_distance(pos, o.center))[:max_candidates]

        result = []
        for obs in nearest:
            approach = self._best_approach_point(env, obs.center, pos)
            if approach is not None:
                result.append((approach, obs.center))
        return result

    def _best_approach_point(self, env: WildfireEnvironment, fire_center: WorldPos, truck_pos: WorldPos) -> WorldPos | None:
        """
        Sample 8 candidate positions around fire_center at extinguish range,
        filter to those not inside an obstacle, and return the one closest to
        the truck's current position. Returns None if all candidates are blocked.
        """
        cx, cy = fire_center
        offset = cfg.EXTINGUISH_RADIUS * 0.8
        # 8-directional candidates; diagonals use 0.7 ~= 1/√2
        dirs = [
            (-0.7, 0.7),  (0, 1), (0.7, 0.7),
              (-1,   0),            (1,   0),
            (-0.7,-0.7), (0, -1), (0.7,-0.7),
        ]
        candidates = [
            (cx + dx * offset, cy + dy * offset)
            for dx, dy in dirs
            if env.is_point_free(cx + dx * offset, cy + dy * offset)
        ]
        if not candidates:
            return None
        return min(candidates, key=lambda p: euclidean_distance(truck_pos, p))
