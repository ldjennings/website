"""SM-465 transmission environment: mesh construction and collision detection."""

from transmission.environment.meshes import (
    build_mainshaft_mesh,
    build_countershaft_mesh,
    build_enclosure_mesh,
)
from transmission.environment.collision import (
    TransmissionCollisionChecker,
)

__all__ = [
    "build_mainshaft_mesh",
    "build_countershaft_mesh",
    "build_enclosure_mesh",
    "TransmissionCollisionChecker",
]
