import argparse
from pathlib import Path

import numpy as np

from transmission.planner import find_path, PlannerConfig
from transmission.visualization import plot_all


def parse_args():
    p = argparse.ArgumentParser(prog="treemission", description="SM-465 mainshaft removal planner")
    p.add_argument("--seed",       type=int,   default=np.random.randint(0, 2**32 -1))
    p.add_argument("--iterations", type=int,   default=30000)
    p.add_argument("--no-viz",     action="store_true", help="Skip figure generation")
    p.add_argument("--out-dir",    type=Path,  default=Path("./out/"))
    return p.parse_args()


def main():
    args = parse_args()

    pc = PlannerConfig(
        max_iterations = args.iterations,
        step_size      = 25.0,
        step_size_rot  = 0.12,
        connect_radius = 60.0,
        edge_checks    = 10,
        seed           = args.seed,
    )

    print(f"Seed: {args.seed}")
    result = find_path(pc)

    if result is None:
        print("No path found.")
        return

    print(f"\nDone — {result.iterations} iterations, {result.planning_time:.1f}s")
    print(f"  Raw waypoints:    {len(result.path)}")
    print(f"  Smooth waypoints: {len(result.smooth_path)}")

    if not args.no_viz:
        plot_all(result, args.out_dir)


if __name__ == "__main__":
    main()
