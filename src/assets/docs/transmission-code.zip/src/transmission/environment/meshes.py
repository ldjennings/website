"""
Trimesh mesh construction for the SM-465 transmission components.

Coordinate system:
- X axis: along shaft axis (input = -X, output = +X)
- Y axis: lateral
- Z axis: vertical (up)
- Enclosure centered at origin in X,Y with base at Z=0
"""

import numpy as np
import trimesh
from trimesh import Trimesh
from trimesh.creation import box
from trimesh.boolean import difference, union
from enum import Enum

from transmission.config import (
    GEAR_THICKNESS, COLLAR_THICKNESS, SYNCRO_THICKNESS,
    SYNCRO12_RADIUS, SYNCRO34_RADIUS,
    GEAR1_RADIUS, GEAR2_RADIUS, GEAR3_RADIUS, GEAR_REV_RADIUS,
    COLLAR12_RADIUS, COLLAR34_RADIUS,
    SHAFT_RADIUS, MAINSHAFT_LENGTH,
    ENCLOSURE_THICKNESS, ENCLOSURE_LENGTH, ENCLOSURE_WIDTH, ENCLOSURE_HEIGHT,
    BEARING_RADIUS, MAINSHAFT_BEARING_HEIGHT, CS_BEARING_HEIGHT,
    COUNTERSHAFT_LENGTH,
    CS_GEAR1_RADIUS, CS_GEAR2_RADIUS, CS_GEAR3_RADIUS,
    CS_GEAR_REV_RADIUS, CS_COUNTERGEAR_RADIUS,
    N_CYL_SECTIONS,
)


class Axis(Enum):
    X = [1, 0, 0]
    Y = [0, 1, 0]
    Z = [0, 0, 1]


def rotation_matrix(degrees: float, axis: Axis) -> np.ndarray:
    return trimesh.transformations.rotation_matrix(np.radians(degrees), axis.value)


# =============================================================================
# Primitive builders (private)
# =============================================================================

def _cylinder(height: float, radius: float, center: bool = False) -> Trimesh:
    """Cylinder along Z. Bottom at Z=0 unless center=True."""
    cyl = trimesh.creation.cylinder(radius=radius, height=height, sections=N_CYL_SECTIONS)
    if not center:
        cyl.apply_translation([0, 0, height / 2])
    return cyl


def _syncro(radius: float, z_offset: float) -> Trimesh:
    return _cylinder(SYNCRO_THICKNESS, radius).apply_translation([0, 0, z_offset])


def _collar(radius: float, z_offset: float) -> Trimesh:
    return _cylinder(COLLAR_THICKNESS, radius).apply_translation([0, 0, z_offset])


def _gear(radius: float, z_offset: float) -> Trimesh:
    return _cylinder(GEAR_THICKNESS, radius).apply_translation([0, 0, z_offset])


def _shaft(length: float, radius: float) -> Trimesh:
    return _cylinder(length, radius)


# =============================================================================
# Mainshaft
# =============================================================================

def build_mainshaft_mesh() -> Trimesh:
    """Mainshaft assembly in local frame (shaft along +Z, centroid at origin)."""
    parts = [_shaft(MAINSHAFT_LENGTH, SHAFT_RADIUS)]

    z = 20.0  # shaft_offset
    parts.append(_syncro(SYNCRO34_RADIUS, z)); z += SYNCRO_THICKNESS
    parts.append(_collar(COLLAR34_RADIUS, z)); z += COLLAR_THICKNESS
    parts.append(_syncro(SYNCRO34_RADIUS, z)); z += SYNCRO_THICKNESS
    parts.append(_gear(GEAR3_RADIUS, z));      z += GEAR_THICKNESS
    parts.append(_gear(GEAR2_RADIUS, z));      z += GEAR_THICKNESS
    parts.append(_syncro(SYNCRO12_RADIUS, z)); z += SYNCRO_THICKNESS
    parts.append(_gear(GEAR_REV_RADIUS, z));   z += GEAR_THICKNESS
    parts.append(_collar(COLLAR12_RADIUS, z)); z += COLLAR_THICKNESS
    parts.append(_syncro(SYNCRO12_RADIUS, z)); z += SYNCRO_THICKNESS
    parts.append(_gear(GEAR1_RADIUS, z))

    combined = union(parts)
    combined.apply_translation([0, 0, -MAINSHAFT_LENGTH / 2])
    return combined


# =============================================================================
# Countershaft
# =============================================================================

def build_countershaft_mesh() -> Trimesh:
    """Countershaft assembly placed in world frame."""
    shaft_offset = 38.0
    parts = [_shaft(COUNTERSHAFT_LENGTH, SHAFT_RADIUS)]

    parts.append(_gear(CS_GEAR1_RADIUS,   shaft_offset))
    parts.append(_gear(CS_GEAR_REV_RADIUS, shaft_offset + SYNCRO_THICKNESS + COLLAR_THICKNESS + GEAR_THICKNESS))
    parts.append(_gear(CS_GEAR2_RADIUS,   shaft_offset + 2 * SYNCRO_THICKNESS + COLLAR_THICKNESS + 2 * GEAR_THICKNESS))
    parts.append(_gear(CS_GEAR3_RADIUS,   shaft_offset + 2 * SYNCRO_THICKNESS + COLLAR_THICKNESS + 3 * GEAR_THICKNESS))
    parts.append(_gear(CS_COUNTERGEAR_RADIUS, COUNTERSHAFT_LENGTH - 2 * ENCLOSURE_THICKNESS - 5))

    combined = union(parts)

    # Transform to world frame: OpenSCAD translate([165, 0, 112.5]) rotate([0, 90, 180])
    R = rotation_matrix(180, Axis.Z) @ rotation_matrix(90, Axis.Y)
    combined.apply_transform(R)
    combined.apply_translation([
        0.5 * ENCLOSURE_LENGTH + ENCLOSURE_THICKNESS,   # 165
        0.0,
        CS_BEARING_HEIGHT + 0.5 * ENCLOSURE_THICKNESS,  # 112.5
    ])
    return combined


# =============================================================================
# Enclosure
# =============================================================================

def _base_module() -> Trimesh:
    return trimesh.creation.box(
        extents=[ENCLOSURE_LENGTH, ENCLOSURE_WIDTH, ENCLOSURE_THICKNESS]
    )


def _sidewall_module() -> Trimesh:
    return difference([
        box(extents=[ENCLOSURE_LENGTH, ENCLOSURE_THICKNESS, ENCLOSURE_HEIGHT]),
        box(extents=[0.35 * ENCLOSURE_LENGTH, 1.2 * ENCLOSURE_THICKNESS, 0.45 * ENCLOSURE_HEIGHT])
            .apply_translation([-0.25 * ENCLOSURE_LENGTH, 0, -0.2 * ENCLOSURE_HEIGHT]),
    ])


def _endwall_module() -> Trimesh:
    """End wall with bearing bores for both shafts."""
    half_panel_h = 0.5 * (ENCLOSURE_HEIGHT + ENCLOSURE_THICKNESS)
    bore_length  = ENCLOSURE_THICKNESS + 10

    def _bearing_bore(height_above_base: float) -> Trimesh:
        return (
            _cylinder(bore_length, BEARING_RADIUS, center=True)
            .apply_transform(rotation_matrix(90, Axis.Y))
            .apply_translation([0, 0, height_above_base + ENCLOSURE_THICKNESS - half_panel_h])
        )

    return difference([
        box(extents=[ENCLOSURE_THICKNESS, ENCLOSURE_WIDTH, ENCLOSURE_HEIGHT + ENCLOSURE_THICKNESS]),
        _bearing_bore(MAINSHAFT_BEARING_HEIGHT),
        _bearing_bore(CS_BEARING_HEIGHT),
    ])


def build_enclosure_mesh() -> Trimesh:
    """Transmission enclosure: base + 2 end walls + 2 side walls.

    See scad_files/transmission.scad for the original OpenSCAD model.
    """
    eps   = 0.01
    half_l = 0.5 * ENCLOSURE_LENGTH
    half_h = 0.5 * ENCLOSURE_HEIGHT
    half_w = 0.5 * ENCLOSURE_WIDTH
    half_t = 0.5 * ENCLOSURE_THICKNESS

    return union([
        _base_module(),
        _endwall_module().apply_translation(( half_l + half_t - eps, 0,  half_h)),
        _endwall_module().apply_translation((-half_l - half_t + eps, 0,  half_h)),
        _sidewall_module().apply_translation((0, -half_w + half_t,  half_h + half_t - eps)),
        _sidewall_module().apply_translation((0,  half_w - half_t,  half_h + half_t - eps)),
    ])
