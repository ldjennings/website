"""
Procedural generation of obstacle grids using tetromino shapes.

Grids are 2D integer arrays where 1 = occupied, 0 = free.
Adapted from the valet assignment grid generator.
"""

import numpy as np


TETROMINOES = {
    0: [(0, 0), (1, 0), (0, 1), (1, 1)],   # square
    1: [(0, 0), (1, 0), (2, 0), (1, 1)],   # T
    2: [(0, 0), (0, 1), (1, 1), (2, 1)],   # L
    3: [(0, 0), (0, 1), (1, 0), (2, 0)],   # J
    4: [(0, 0), (1, 0), (2, 0), (3, 0)],   # I
    5: [(0, 0), (0, 1), (1, 1), (1, 2)],   # S
    6: [(1, 0), (1, 1), (0, 1), (0, 2)],   # Z
}


def rotate_shape(shape: list[tuple[int, int]], k: int) -> list[tuple[int, int]]:
    """Rotate a tetromino shape by 90 degrees k times."""
    rotated = shape
    for _ in range(k):
        rotated = [(c, -r) for (r, c) in rotated]
    return rotated


def populate_grid(
    grid_shape: tuple[int, int],
    coverage: float,
    rng: np.random.Generator | None = None,
) -> np.ndarray:
    """
    Fill a grid with randomly placed and rotated tetrominoes until
    the fraction of occupied cells reaches `coverage`.

    Args:
        grid_shape: (num_rows, num_cols).
        coverage:   Target fill fraction in [0, 1].
        rng:        Numpy random generator for reproducibility.
    """
    assert 0 <= coverage <= 1.0

    if rng is None:
        rng = np.random.default_rng()

    num_rows, num_cols = grid_shape
    grid = np.zeros((num_rows, num_cols), dtype=int)
    target_cells = int(num_rows * num_cols * coverage)

    while grid.sum() < target_cells:
        tet_type = int(rng.integers(0, len(TETROMINOES)))
        shape = TETROMINOES[tet_type]
        shape = rotate_shape(shape, int(rng.integers(0, 4)))

        row = int(rng.integers(0, num_rows))
        col = int(rng.integers(0, num_cols))

        for dr, dc in shape:
            r, c = row + dr, col + dc
            if 0 <= r < num_rows and 0 <= c < num_cols:
                grid[r, c] = 1

    return grid
