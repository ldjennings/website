"""SM-465 mainshaft removal planner."""

from transmission.config import INITIAL_POSE, GOAL_POSE
from transmission.environment.collision import TransmissionCollisionChecker
from transmission.planner.rrt import (
    RRTTree, RRTNode, PlanResult, PlannerConfig, plan_birrt,
)
from transmission.planner.postprocessing import smooth_path

__all__ = [
    "find_path",
    "PlanResult",
    "PlannerConfig",
    "RRTTree",
    "RRTNode",
    "plan_birrt",
    "smooth_path",
]


def find_path(pc: PlannerConfig | None = None) -> PlanResult | None:
    """Build the collision checker and run BiRRT from the configured start/goal."""
    checker = TransmissionCollisionChecker()
    return plan_birrt(checker, INITIAL_POSE, GOAL_POSE, pc or PlannerConfig())
