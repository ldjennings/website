"""
Visualization of BiRRT results: path, tree structure, and removal animation.
"""

from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

from transmission.state_utils import rotation_from_spherical, interpolate_pose
from transmission.environment import (
    build_mainshaft_mesh, build_countershaft_mesh, build_enclosure_mesh,
)
from transmission.planner.rrt import PlanResult, RRTTree

_VIEW_ELEV      = 25
_VIEW_AZIM      = 60
_TITLE_Y        = 1.0   # vertical position of 3D subplot titles (1.0 = top of axes box)
_TITLE_FONTSIZE = 15
_LEGEND_FONTSIZE = 10

# =============================================================================
# Mesh rendering helpers
# =============================================================================

def trimesh_to_poly3d(mesh, color, alpha=0.5) -> Poly3DCollection:
    return Poly3DCollection(mesh.vertices[mesh.faces], alpha=alpha,
                            facecolor=color, edgecolor=color, linewidth=0.2)


def transform_mesh_by_pose(mesh, pose):
    m = mesh.copy()
    T = np.eye(4)
    T[:3, :3] = rotation_from_spherical(pose[3], pose[4])
    T[:3, 3]  = pose[:3]
    m.apply_transform(T)
    return m

# =============================================================================
# Pyplot helpers
# =============================================================================


def draw_environment(ax, alpha_enclosure=0.1, alpha_cs=0.4):
    """Draw the static enclosure and countershaft."""
    enclosure = build_enclosure_mesh()
    cs        = build_countershaft_mesh()
    ax.add_collection3d(trimesh_to_poly3d(enclosure, 'steelblue', alpha_enclosure))
    ax.add_collection3d(trimesh_to_poly3d(cs,        'orange',    alpha_cs))
    return enclosure, cs


def setup_axes(ax, title: str = "", extra_points: np.ndarray | None = None, *,
               legend: bool = False,
               alpha_enclosure: float = 0.1,
               alpha_cs: float = 0.4) -> None:
    # Render static environment geometry into the axes
    enclosure, _ = draw_environment(ax, alpha_enclosure, alpha_cs)

    # Strip labels and ticks — numeric values aren't meaningful in pose space
    ax.set_xlabel(''); ax.set_ylabel(''); ax.set_zlabel('')
    ax.tick_params(labelsize=0, length=0)
    if title:
        ax.set_title(title, y=_TITLE_Y, fontsize=_TITLE_FONTSIZE)

    # Fixed camera angle keeps all views visually consistent
    ax.view_init(elev=_VIEW_ELEV, azim=_VIEW_AZIM)

    # Fit bounds to enclosure + any caller-supplied path or config points
    pts = enclosure.vertices if extra_points is None else np.vstack([enclosure.vertices, extra_points])
    set_equal_axes(ax, pts)

    if legend:
        ax.legend(fontsize=_LEGEND_FONTSIZE, loc='upper right')


def set_equal_axes(ax, points: np.ndarray):
    """Set equal aspect ratio for a 3D axes given a cloud of points."""
    max_range = np.max(points.max(axis=0) - points.min(axis=0)) / 2
    mid       = (points.max(axis=0) + points.min(axis=0)) / 2
    margin    = max_range * 1.1
    ax.set_xlim(mid[0] - margin, mid[0] + margin)
    ax.set_ylim(mid[1] - margin, mid[1] + margin)
    ax.set_zlim(mid[2] - margin, mid[2] + margin)


def draw_path(ax, path_arr: np.ndarray, *,
              marker_arr: np.ndarray | None = None,
              endpoints: bool = False,
              waypoints: bool = False,
              linewidth: float = 2,
              alpha: float = 1.0,
              label: str | None = None) -> None:
    pts = path_arr[:, :3]
    ax.plot(*pts.T, 'r-', linewidth=linewidth, alpha=alpha, label=label)
    mkr = marker_arr[:, :3] if marker_arr is not None else pts
    if waypoints:
        ax.scatter(*mkr.T, color='darkred', s=40, zorder=5)
    if endpoints:
        ax.scatter(*mkr[0],  color='green', s=100, zorder=5, label='Start')
        ax.scatter(*mkr[-1], color='red',   s=100, zorder=5, label='Goal')


def densify_path(path: list, n_per_segment: int = 5) -> list:
    """Insert interpolated poses between waypoints for smoother visualization."""
    dense = [path[0]]
    for i in range(len(path) - 1):
        for j in range(1, n_per_segment + 1):
            dense.append(interpolate_pose(path[i], path[i + 1], j / n_per_segment))
    return dense


# =============================================================================
# Figure 1: raw path vs smoothed path
# - countershaft, enclosure included, mainshaft is not
# - start of path represented with green dot
# - end of path represented with green dot
# - edges between points are represented by straight red lines
# - points on the path are only drawn for the smoothed path, represented as 
#   dark red points.
# =============================================================================

def plot_path_figure(result: PlanResult, save_path: Path):
    fig = plt.figure(figsize=(18, 8))

    ax = fig.add_subplot(121, projection='3d')
    raw_path = np.array(result.path)

    draw_path(ax, raw_path, endpoints=True, linewidth=2,
              label=f'Raw path ({len(result.path)} pts)')
    
    setup_axes(ax, f"Raw RRT Path ({len(result.path)} waypoints)",
               raw_path[:, :3], legend=True)

    ax2 = fig.add_subplot(122, projection='3d')
    smooth_arr = np.array(result.smooth_path)
    dense_arr  = np.array(densify_path(result.smooth_path, n_per_segment=10))

    draw_path(ax2, dense_arr, marker_arr=smooth_arr, endpoints=True, waypoints=True,
              linewidth=2.5, label=f'Smoothed ({len(result.smooth_path)} pts)')
    
    setup_axes(ax2, f"Smoothed Path ({len(result.smooth_path)} waypoints)",
               raw_path[:, :3], legend=True)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved {save_path}")


# =============================================================================
# Figure 2: RRT tree structure
# =============================================================================

def _draw_tree(ax, tree: RRTTree, color: str, label: str):
    ax.plot([], [], [], f'{color}-', linewidth=1, alpha=0.4, label=label)
    for node in tree.nodes:
        if node.parent is not None:
            pts = np.array([node.parent.pose[:3], node.pose[:3]])
            ax.plot(*pts.T, f'{color}-', linewidth=2, alpha=0.4)


def plot_tree_figure(result: PlanResult, save_path: Path):
    fig  = plt.figure(figsize=(20, 8))
    dense_arr = np.array(densify_path(result.smooth_path, n_per_segment=10))

    s_configs = np.array([n.pose for n in result.tree_start.nodes])
    g_configs = np.array([n.pose for n in result.tree_goal.nodes])

    # 3D view
    ax1 = fig.add_subplot(131, projection='3d')
    _draw_tree(ax1, result.tree_start, 'b', 'Start tree')
    _draw_tree(ax1, result.tree_goal,  'g', 'Goal tree')
    draw_path(ax1, dense_arr, linewidth=3, label='Solution path')
    setup_axes(ax1, "RRT Tree — 3D View",
               np.vstack([s_configs[:, :3], g_configs[:, :3]]),
               legend=True, alpha_enclosure=0.06, alpha_cs=0.2)

    def draw_2d(ax, xi, yi, title):
        for tree, color in [(result.tree_start, 'b'), (result.tree_goal, 'g')]:
            for node in tree.nodes:
                if node.parent is not None:
                    p = node.parent.pose
                    ax.plot([p[xi], node.pose[xi]], [p[yi], node.pose[yi]],
                            f'{color}-', linewidth=1, alpha=0.4)
        ax.plot(dense_arr[:, xi], dense_arr[:, yi], 'r-', linewidth=2.5)
        ax.set_title(title)
        ax.set_aspect('equal')
        ax.grid(True, alpha=0.3)

    draw_2d(fig.add_subplot(132), 1, 2, 'Front View (Y-Z)')
    draw_2d(fig.add_subplot(133), 0, 1, 'Top View (X-Y)')

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved {save_path}")


# =============================================================================
# Figure 3: multi-frame removal animation
# =============================================================================

def plot_animation_frames(result: PlanResult, save_path: Path, n_frames: int = 8):
    ms_mesh = build_mainshaft_mesh()
    dense   = densify_path(result.smooth_path, n_per_segment=20)
    indices = np.linspace(0, len(dense) - 1, n_frames, dtype=int)

    ncols = 4
    nrows = (n_frames + ncols - 1) // ncols
    fig   = plt.figure(figsize=(5 * ncols, 5 * nrows))

    for fi, idx in enumerate(indices):
        ax = fig.add_subplot(nrows, ncols, fi + 1, projection='3d')
        ms_t = transform_mesh_by_pose(ms_mesh, dense[idx])
        ax.add_collection3d(trimesh_to_poly3d(ms_t, 'firebrick', 0.7))

        path_so_far = np.array(dense[:idx + 1])
        if len(path_so_far) > 1:
            draw_path(ax, path_so_far, linewidth=1.5, alpha=0.5)

        setup_axes(ax, f"t = {idx / (len(dense) - 1):.0%}",
                   ms_t.vertices, alpha_enclosure=0.08, alpha_cs=0.35)

    plt.suptitle("Mainshaft Removal — Path Animation", fontsize=18, y=1.02)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved {save_path}")


# =============================================================================
# Figure 4: overview — shaft at start, intermediate, and goal poses
# =============================================================================

def plot_overview(result: PlanResult, save_path: Path):
    ms_mesh   = build_mainshaft_mesh()
    dense     = densify_path(result.smooth_path, n_per_segment=20)
    dense_arr = np.array(dense)

    fig = plt.figure(figsize=(14, 10))
    ax  = fig.add_subplot(111, projection='3d')

    for frac, color, alpha in zip(
        [0.0, 0.33, 0.66, 1.0],
        ['green', 'goldenrod', 'darkorange', 'firebrick'],
        [0.4, 0.4, 0.4, 0.7],
    ):
        ms_t = transform_mesh_by_pose(ms_mesh, dense[int(frac * (len(dense) - 1))])
        ax.add_collection3d(trimesh_to_poly3d(ms_t, color, alpha))

    draw_path(ax, dense_arr, linewidth=2, alpha=0.8)
    setup_axes(ax, "SM-465 Mainshaft Removal — Path Overview",
               dense_arr[:, :3], alpha_enclosure=0.08, alpha_cs=0.35)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved {save_path}")


# =============================================================================
# Combined entry point
# =============================================================================

def plot_all(result: PlanResult, out_dir: Path = Path('./out/')):
    out_dir.mkdir(exist_ok=True)
    plot_path_figure(     result, out_dir / 'path_figure.svg')
    plot_tree_figure(     result, out_dir / 'tree_figure.svg')
    plot_animation_frames(result, out_dir / 'animation_frames.svg')
    plot_overview(        result, out_dir / 'path_overview.svg')
    print("\nAll figures saved.")
