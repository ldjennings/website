# Wildfire Assignment Requirements

This is a document to tally the requirements for each component of the assignment in one place. Keeping track of all the requirements scattered around the document was difficult, so I organized them here.

## Environment
- Flat square field, 250m on a side
- Base obstacle unit: 5m grid cells
- Players start on opposite sides of the field
- Simulation runs for 3600 seconds (sim time, not real time)
- May end early if steady state is reached
- Each iteration should run within a few minutes or less
- Does not need to run at real time

## Obstacles
- Tetromino shapes (see Figure 1 in PDF for standard free tetrominoes)
- Fill environment to 10% obstacle coverage
- Four singular states: intact, burning, extinguished, burned
- Fire spread: after 10 seconds of burning, sets all obstacles within 30m radius to burning
- Burned obstacles may not be relit

## Wumpus (Discrete Planner)
- Motion confined to a grid
- Uses A* or variant for path planning (Chapter 2, LaValle 2006)
- Grid may be uniform squares or other variations (e.g. hexagonal); any graph density allowed; does not need to match obstacle grid
- Can light fires on obstacles in adjacent graph nodes only
- Can perceive the firetruck
- Does not interact directly with the firetruck

## Firetruck (Sampling-Based Planner)
- Mercedes Unimog, car-like robot with Ackermann steering
  - Width: 2.2m
  - Length: 4.9m
  - Wheelbase: 3.0m
  - Minimum turning radius: 13.0m
  - Maximum velocity: 10 m/s
- Kinematics (including collision) must be considered; full dynamic model optional
- Maximum velocity and minimum turning radius must be enforced
- Instantaneous acceleration is allowed but noted as "destructive to the transmission"
- Has omniscient perception of the environment (drone air support)
- Cannot perceive the Wumpus
- Extinguishes a burning obstacle by stopping for 5 seconds within 10m of it
- Uses a Probabilistic RoadMap (PRM) planner (Chapter 5, LaValle 2006)
- Roadmap may be created a priori or generated as needed
- Local planner must generate kinematically correct paths
- No RRT (saved for next assignment)

## Simulation
- 5 iterations per scenario, each with a different random obstacle field
- 3600 seconds sim time per run

## Scoring
- Wumpus: +1 per obstacle ignited, +1 additional if obstacle fully burns (burned state)
- Firetruck: +2 per obstacle extinguished
- Best of 5 rounds wins the "fancy trophy"

## Undefined / Ambiguous Behavior

| Question | Assumption |
|----------|------------|
| **Extinguished obstacle state**: spec says "burned may not be relit" but is silent on extinguished. Can the Wumpus or fire spread re-ignite it? | Extinguished obstacles cannot be relit. |
| **Wumpus movement speed**: spec says grid-based with A* but never specifies how fast it moves | Tuned so the Wumpus doesn't have an overwhelming advantage against the firetruck. |
| **Wumpus grid shape/density**: "any graph shape/density is allowed" — no specific shape/density given | The wumpus's grid will match the obstacle grid. |
| **Starting positions**: "opposite sides of the field (either in random positions, or at set initial points)" | Truck starts in bottom-left corner, Wumpus in the top-right corner. |
| **Steady state**: mentioned as an early termination condition but not defined | The simulation steady state will be defined as when all obstacles are either burned or extinguished. |
| **"Destructive to the transmission"**: instantaneous acceleration is allowed but described as destructive — unclear if there's a mechanical consequence | The truck survives this assignment with a busted transmission. It will be repaired during the next motion planning homework assignment. No acceleration model needed for this one however. |
| **Fire spread applies to which obstacles?**: the spec says a burning obstacle spreads fire after 10s, but is unclear whether this applies to every burning obstacle or only the one originally lit by the Wumpus | Every burning obstacle spreading gives the Wumpus an overwhelming advantage — after lighting just one obstacle, the chain reaction essentially auto-wins the simulation, with only a few isolated tetrominoes needing to be personally ignited. Rule is therefore applied only to Wumpus-ignited obstacles. |
| **Multiple obstacles within extinguish radius**: if the truck stops within 10m of several burning obstacles simultaneously, it is unclear whether all are extinguished after 5 seconds or only one. | The truck extinguishes one obstacle at a time — specifically the closest one within range. This matches real firetruck behavior (a crew deploys on one structure at a time) and keeps the scoring fair. |


