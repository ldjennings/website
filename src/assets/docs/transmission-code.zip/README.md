# Transmission — RBE 550 Motion Planning

BiRRT motion planner for collision-free mainshaft removal from an SM-465 four-wheel-drive manual transmission. The planner finds a 5-DOF path (position + orientation) that extracts the mainshaft from the assembled transmission without colliding with the countershaft or enclosure.

## Requirements

- Python 3.12+

## Installation

### With uv (recommended)

[uv](https://docs.astral.sh/uv/) handles virtual environment creation and dependency resolution automatically:

```sh
git clone <repo-url>
cd transmission
uv sync
```

### Without uv

```sh
python3.12 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e .
```

## Usage

```sh
uv run treemission [options]
```

| Flag | Effect |
|---|---|
| `--seed N` | Fix the RNG seed for a reproducible result. The seed used by each run is printed to stdout. |
| `--iterations N` | Maximum BiRRT iterations (default: 30 000). |
| `--no-viz` | Skip figure generation after planning. |
| `--out-dir PATH` | Directory for output figures and result data (default: `./out/`). |

### Examples

```sh
# run with a fixed seed
uv run treemission --seed 12345

# run and skip figure generation
uv run treemission --no-viz

# run for more iterations with figures in a custom directory
uv run treemission --iterations 50000 --out-dir results/
```

## Output

A successful run prints the seed, iteration count, planning time, and waypoint counts, then saves:

- `out/path_figure.svg` — raw vs smoothed path comparison
- `out/tree_figure.svg` — RRT tree structure (3D, front, top views)
- `out/animation_frames.svg` — multi-frame removal sequence
- `out/path_overview.svg` — shaft at start, intermediate, and goal poses

## Project Structure

```
src/          Python source (planner, collision checker, environment, visualisation)
report/       Typst report and supporting figures
out/          Generated figures and result data (after running)
```