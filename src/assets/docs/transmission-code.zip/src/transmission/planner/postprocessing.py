"""
Path postprocessing: shortcut smoothing for RRT paths.
"""

import numpy as np

from transmission.aliases import ShaftPose
from transmission.environment import TransmissionCollisionChecker


def smooth_path(path: list[ShaftPose],
                checker: TransmissionCollisionChecker,
                max_iterations: int = 200,
                rng: np.random.Generator | None = None) -> list[ShaftPose]:
    """Shortcut smoothing: repeatedly try to replace a stretch of waypoints
    with a direct collision-free edge between two randomly chosen endpoints.
    """
    if rng is None:
        rng = np.random.default_rng(123)

    path = list(path)

    for _ in range(max_iterations):
        if len(path) <= 2:
            break

        i = int(rng.integers(0, len(path) - 1))
        j = int(rng.integers(i + 1, len(path)))

        if j - i <= 1:
            continue

        if checker.check_path_segment(path[i], path[j]):
            path = path[:i + 1] + path[j:]

    return path
