"""
State dataclasses for firetruck and wumpus.

Frozen + slotted for hashability and memory efficiency, matching
the valet project's state conventions.
"""

from dataclasses import dataclass
import math

import numpy as np

import wildfire.config as cfg


def sample_random_state(rng: np.random.Generator) -> "TruckState":
    """Sample a uniformly random TruckState within the field."""
    margin = math.hypot(cfg.TRUCK_WIDTH, cfg.TRUCK_LENGTH) / 2  # bounding radius: keeps the truck body inside the field boundary
    x = float(rng.uniform(margin, cfg.FIELD_SIZE - margin))
    y = float(rng.uniform(margin, cfg.FIELD_SIZE - margin))
    h = float(rng.uniform(-math.pi, math.pi))
    return TruckState(x, y, h)


@dataclass(frozen=True, slots=True)
class TruckState:
    """
    Car-like (Ackermann) robot state.

    (rear_axle_x, rear_axle_y) is the center of the rear axle in meters.
    heading_rad is the vehicle heading in world space (radians).
    """

    rear_axle_x: float
    rear_axle_y: float
    heading_rad: float

    def __iter__(self):
        yield self.rear_axle_x
        yield self.rear_axle_y
        yield self.heading_rad

    def interpolate(self, other: "TruckState", t: float) -> "TruckState":
        return TruckState(
            rear_axle_x=self.rear_axle_x + t * (other.rear_axle_x - self.rear_axle_x),
            rear_axle_y=self.rear_axle_y + t * (other.rear_axle_y - self.rear_axle_y),
            heading_rad=self.heading_rad + t * (other.heading_rad - self.heading_rad),
        )


@dataclass(frozen=True, slots=True)
class WumpusState:
    """
    Grid-based wumpus position.

    (grid_row, grid_col) indexes the navigation grid directly.
    """

    grid_row: int
    grid_col: int

    @property
    def world_pos(self) -> tuple[float, float]:
        """World-space center (x, y) of the occupied cell."""
        x = (self.grid_col + 0.5) * cfg.CELL_SIZE
        y = (self.grid_row + 0.5) * cfg.CELL_SIZE
        return (x, y)
