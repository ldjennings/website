"""
Agent implementations: firetruck and wumpus.
"""
from .state import TruckState, WumpusState, sample_random_state
from .firetruck import Firetruck, is_valid_pose
from .wumpus import Wumpus
