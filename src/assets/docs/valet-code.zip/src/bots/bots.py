"""
Kinematics and interface implementations for each robot type.

Defines the Bot Protocol (structural interface) and four concrete implementations:
PointBot, DiffBot, CarBot, and TrailerBot. Each pairs with a corresponding state
type from BotState and implements footprint generation, goal checking, trajectory
generation, and keyboard input handling.

Robot dimensions and goal tolerances are constructor parameters with sensible
defaults, so the Bots package has no dependency on simulator.config.
"""

from bots.state import (
    S,
    PointState,
    DiffState,
    CarState,
    Rotateable,
    TrailerState,
)
from utils import angle_difference, direction, center_distance, angle_distance, linspace_xy, rs_path_length, rs_path_sample, steps_to_cover, arc_trajectory, Position
from bots.geometry import (
    point_geom, place, truck_trailer_approximate, truck_trailer_geom,
    make_point_base, make_centered_rect_base, make_axle_rect_base,
    build_heading_cache, lookup_cached, FootprintEntry
)

import math
from typing import Protocol
import pygame
import config as cfg


STANDARD_SPEED = 5.0


def _n_steps_for_control(spacing: float, angular_spacing: float, v: float, omega: float, dt: float) -> int:
    """
    Compute how many simulation steps a (v, omega) control pair needs so that
    the XY displacement is at least `spacing` or their heading displacement is
    at least 'angular_spacing'.
    """
    n_xy = steps_to_cover(spacing, abs(v) * dt)

    if abs(omega) < 1e-9: # just a straight primitive
        return n_xy

    n_heading = steps_to_cover(angular_spacing, abs(omega) * dt)

    return max(n_xy, n_heading)


class Bot(Protocol[S]):
    """
    Structural protocol defining the interface all bot types must satisfy.
    Generic over S (the state type) — a Bot[PointState] only accepts PointState,
    a Bot[DiffState] only accepts DiffState, etc.

    Uses Protocol rather than ABC so implementing classes don't need to explicitly
    inherit from Bot — the type checker verifies the interface is satisfied
    structurally based on method signatures alone.
    """

    def footprint(self, state: S, approximate: bool = False) -> list[FootprintEntry]:
        """Returns the robot's collision geometries as (x_offset, y_offset, geometry) tuples.
        Translating shapely geometry is surprisingly expensive, for now the following applies as an optimization:
        If approximate=True, geometry is pre-rotated but NOT translated — offset is (x, y).
        If approximate=False, geometry is fully placed — offset is (0, 0)."""
        ...

    def generate_trajectory(self, start: S, goal: S, resolution: float = 0.1) -> list[S] | None:
        """
        Generate a kinematically correct trajectory from start to goal.

        Returns a list of states at approximately `resolution` meter intervals,
        or None if no feasible connection exists (e.g. non-holonomic bots that
        lack a closed-form BVP solution).
        """
        ...

    TERMINAL_RADIUS: float

    def is_terminal(self, state: S, goal: S) -> bool:
        """
        Returns True if state is close enough to goal to fire the terminal
        connection (positional check only — heading is handled by generate_trajectory).
        Each bot sets its own terminal_radius based on kinematic constraints.
        """
        ...

    def heuristic(self, state: S, goal: S) -> float:
        """
        Admissible cost-to-go estimate from state to goal.
        Non-holonomic bots use a Reeds-Shepp path length (ignoring obstacles);
        holonomic bots use Euclidean distance.
        """
        ...

    def at_goal(self, state: S, goal: S) -> bool:
        """
        Returns True if state is close enough to goal state to end simulation.
        Checks position for all bots, plus heading for diff/car/trailer, plus
        hitch angle for trailer.
        """
        ...

    def handle_input(self, state: S, speed: float) -> S:
        """
        Applies keyboard input to produce the next state. Used in manual mode
        for debugging kinematics before trusting the planner.
        Kinematically correct — uses the same step() functions as primitive generation.
        """
        ...

    def propagate(self, state: S, spacing: float, angular_spacing: float, steering_granularity: int) -> list[tuple[list[S], float]]:
        """
        Generate one (trajectory, arc_length) pair per sampled control input.

        Each trajectory is long enough that its XY displacement covers at least
        `spacing` meters, so every primitive lands in a new grid cell.
        Turning primitives are additionally lengthened so that heading changes by
        at least `angular_spacing` radians, ensuring they land in a distinct heading bin.
        `steering_granularity` controls how many steering/omega values are
        sampled between 0 and max on each side (e.g. 3 → [-max, -2/3, -1/3, 0, 1/3, 2/3, max]).

        arc_length is the translational distance only (|v| * n_steps * dt), exact for
        constant-curvature arcs. The caller adds the angular cost from the endpoint states.
        """
        ...




# ── Base class ────────────────────────────────────────────────────────────────

class BotBase:
    """Shared implementations for heuristic, is_terminal, and at_goal.

    Subclasses set TERMINAL_RADIUS, goal_radius_tol, and angular_tolerances
    (one entry per angle component in the state — empty for PointBot,
    (heading_tol,) for Diff/Car, (heading_tol, trailer_tol) for Trailer).
    """

    TERMINAL_RADIUS: float
    goal_radius_tol: float
    goal_heading_tol: float
    trailer_heading_tol: float
    SPEED = STANDARD_SPEED
    turning_radius: float


    def is_terminal(self, state: S, goal: S) -> bool:
        return center_distance(state.position(), goal.position()) < self.TERMINAL_RADIUS

    def heuristic(self, state: S, goal: S) -> float:
        if isinstance(state, Rotateable) and isinstance(goal, Rotateable):
            return rs_path_length(state, goal, self.turning_radius)
        else:
            return center_distance(state.position(), goal.position())

    def at_goal(self, state: S, goal: S) -> bool:
        if center_distance(state.position(), goal.position()) >= self.goal_radius_tol:
            return False
        match (state, goal):
            case (PointState(), PointState()):
                return True
            case (DiffState(heading_rad=h0), DiffState(heading_rad=h1)):
                return angle_distance(h0, h1) < self.goal_heading_tol
            case (CarState(heading_rad=h0), CarState(heading_rad=h1)):
                return angle_distance(h0, h1) < self.goal_heading_tol
            case (TrailerState(heading_rad=h0, trailer_heading_rad=th0),
                TrailerState(heading_rad=h1, trailer_heading_rad=th1)):
                return (
                    angle_distance(h0, h1) < self.goal_heading_tol and
                    angle_distance(th0, th1) < self.trailer_heading_tol
                )
            case _ as unreachable:
                raise AssertionError(f"Unhandled state pair: {type(unreachable)}")


# ── PointBot ──────────────────────────────────────────────────────────────────

class PointBot(BotBase):
    """Holonomic point robot. Can move in any direction; no heading or turning constraints."""

    TERMINAL_RADIUS = 5.0


    def __init__(self, goal_radius_tol: float = cfg.GOAL_RADIUS_TOLERANCE):
        self.goal_radius_tol = goal_radius_tol
        self._base = make_point_base()
        self._base_bounds = self._base.bounds

    def footprint(self, state: PointState, approximate: bool = False) -> list[FootprintEntry]:
        x, y = state.position()
        if approximate:
            return [(x, y, self._base, self._base_bounds)]
        g = point_geom(self._base, state)
        return [(0, 0, g, g.bounds)]

    def generate_trajectory(
        self, start: PointState, goal: PointState, resolution: float = 0.1
    ) -> list[PointState] | None:
            return [PointState(*p) for p in linspace_xy(start.position(), goal.position(), resolution)]

    def propagate(self, state: PointState, spacing: float, angular_spacing: float, steering_granularity: int) -> list[tuple[list[PointState], float]]:
        """Generate one primitive per compass direction (8-connected).

        n_steps is chosen so the diagonal displacement per axis >= spacing:
        diagonal per-axis = n * step / sqrt(2) >= spacing → n >= spacing * sqrt(2) / step.
        angular_spacing and steering_granularity are unused — PointBot has no heading.
        """
        step = self.SPEED * cfg.DT
        n_steps = steps_to_cover(spacing * math.sqrt(2), step)
        arc_length = step * n_steps  # each step has magnitude `step` regardless of direction
        trajectories = []
        for dx, dy in [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]:
            norm = math.hypot(dx, dy)
            sx, sy = dx / norm * step, dy / norm * step
            traj: list[PointState] = [state]
            for _ in range(n_steps):
                traj.append(traj[-1].translate(sx, sy))
            trajectories.append((traj, arc_length))
        return trajectories

    def handle_input(self, state: PointState, speed: float) -> PointState:
        keymap = {
            pygame.K_LEFT: (-0.5, 0),
            pygame.K_RIGHT: (0.5, 0),
            pygame.K_UP: (0, -0.5),
            pygame.K_DOWN: (0, 0.5),
        }

        keys = pygame.key.get_pressed()

        new_state = state

        for k, delta in keymap.items():
            if keys[k]:
                new_state = new_state.translate(delta[0], delta[1])

        return new_state




# ── DiffBot ───────────────────────────────────────────────────────────────────

class DiffBot(BotBase):
    """Differential drive robot. Can rotate in place; forward/backward and in-place turning."""

    OMEGA_MAX       = math.pi / 2      # rad/s
    TERMINAL_RADIUS = 2.0
    turning_radius = cfg.ROBOT_WIDTH_METERS # sample thing for the distance calcs

    def __init__(
        self,
        length: float = cfg.ROBOT_LENGTH_METERS,
        width: float = cfg.ROBOT_WIDTH_METERS,
        goal_radius_tol: float = cfg.GOAL_RADIUS_TOLERANCE,
        goal_heading_tol: float = cfg.GOAL_HEADING_TOLERANCE,
    ):
        self.goal_radius_tol = goal_radius_tol
        self.goal_heading_tol = goal_heading_tol
        self._base = make_centered_rect_base(length, width)
        self._cache = build_heading_cache(self._base)


    def footprint(self, state: DiffState, approximate: bool = False) -> list[FootprintEntry]:
        x, y, h = state.center_x, state.center_y, state.heading_rad
        if approximate:
            geom, bounds = lookup_cached(self._cache, h)
            return [(x, y, geom, bounds)]
        g = place(self._base, x, y, h)
        return [(0, 0, g, g.bounds)]

    def generate_trajectory(
        self, start: DiffState, goal: DiffState, resolution: float = 0.1
    ) -> list[DiffState] | None:
        """
        Connect start to goal via rotate-drive-rotate, interpolated at
        `resolution`-sized steps using linspace. No discrete stepping,
        so no accumulation error or overshoot.
        """
        states: list[DiffState] = []

        p1 = start.position()
        p2 = goal.position()

        if center_distance(p1, p2) > 1e-3:
            # Phase 1: rotate to face goal
            angle_to_goal = direction(start.position(), goal.position())
            facing_goal = DiffState(start.center_x, start.center_y, angle_to_goal)
            states.extend(start.pure_rotation_linspace(facing_goal, resolution))

            # Phase 2: drive straight
            for (x, y) in linspace_xy(p1, p2, resolution):
                states.append(DiffState(x, y, angle_to_goal))

            heading_after_drive = angle_to_goal
        else:
            states.append(start)
            heading_after_drive = start.heading_rad

        # Phase 3: rotate to goal heading
        if angle_distance(goal.heading_rad, heading_after_drive) > 1e-6:
            states.extend(states[-1].pure_rotation_linspace(goal, resolution))

        return states

    def propagate(self, state: DiffState, spacing: float, angular_spacing: float, steering_granularity: int) -> list[tuple[list[DiffState], float]]:
        omegas = [
            self.OMEGA_MAX * i / steering_granularity
            for i in range(-steering_granularity, steering_granularity + 1)
        ]
        x0, y0, h0 = state.center_x, state.center_y, state.heading_rad
        trajectories = []
        for v in (self.SPEED, -self.SPEED): # forward and reverse sets
            for omega in omegas: # each subdivision of the max angular velocity

                # figure out how many steps you need to get to a new xy bin
                n_steps = _n_steps_for_control(spacing, angular_spacing, v, omega, cfg.DT)

                arr = arc_trajectory(x0, y0, h0, v, omega, n_steps, cfg.DT)
                traj = [DiffState(row[0], row[1], row[2]) for row in arr]
                trajectories.append((traj, abs(v) * n_steps * cfg.DT))


        # rotate in place: v=0, so arc_length = 0; arc_trajectory handles this correctly (R=0)
        n_rot = steps_to_cover(angular_spacing, self.OMEGA_MAX * cfg.DT)
        for omega in (-self.OMEGA_MAX, self.OMEGA_MAX):
            arr = arc_trajectory(x0, y0, h0, 0.0, omega, n_rot, cfg.DT)
            traj = [DiffState(row[0], row[1], row[2]) for row in arr]
            trajectories.append((traj, 0.0))
        return trajectories

    def handle_input(self, state: DiffState, speed: float) -> DiffState:
        v, omega = 0.0, 0.0

        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP] and not keys[pygame.K_DOWN]:
            v = speed
        elif keys[pygame.K_DOWN] and not keys[pygame.K_UP]:
            v = -speed
        if keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT]:
            omega = -speed
        elif keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]:
            omega = speed
        return state.step(v, omega, cfg.DT)



# ── CarBot ────────────────────────────────────────────────────────────────────

class CarBot(BotBase):
    """Ackermann steering (car-like) robot. Non-holonomic; minimum turning radius determined by MAX_STEER."""

    MAX_STEER       = math.radians(45)
    TERMINAL_RADIUS = 9.0

    def __init__(
        self,
        wheelbase: float = cfg.CAR_WHEELBASE_METERS,
        length: float = cfg.CAR_LENGTH_METERS,
        width: float = cfg.CAR_WIDTH_METERS,
        goal_radius_tol: float = cfg.GOAL_RADIUS_TOLERANCE,
        goal_heading_tol: float = cfg.GOAL_HEADING_TOLERANCE,
    ):
        self.wheelbase = wheelbase
        self.turning_radius = wheelbase / math.tan(self.MAX_STEER)
        self.goal_radius_tol = goal_radius_tol
        self.goal_heading_tol = goal_heading_tol
        self._base = make_axle_rect_base(wheelbase, length, width)
        self._cache = build_heading_cache(self._base)


    def footprint(self, state: CarState, approximate: bool = False) -> list[FootprintEntry]:
        x, y, h = state.rear_axle_x, state.rear_axle_y, state.heading_rad
        if approximate:
            geom, bounds = lookup_cached(self._cache, h)
            return [(x, y, geom, bounds)]
        g = place(self._base, x, y, h)
        return [(0, 0, g, g.bounds)]

    def generate_trajectory(self, start: CarState, goal: CarState, resolution: float = 0.1) -> list[CarState] | None:
        """Connect start to goal via a Reeds-Shepp path. Returns None if pyReedsShepp finds no path."""
        raw = rs_path_sample(start.pose(), goal.pose(), self.turning_radius, resolution)
        if raw is None:
            return None
        path = [CarState(r[0], r[1], r[2]) for r in raw]
        path.append(goal)
        return path

    def propagate(self, state: CarState, spacing: float, angular_spacing: float, steering_granularity: int) -> list[tuple[list[CarState], float]]:
        deltas = [
            self.MAX_STEER * i / steering_granularity
            for i in range(-steering_granularity, steering_granularity + 1)
        ]
        x0, y0, h0 = state.pose()
        trajectories = []
        for v in (self.SPEED, -self.SPEED):
            for delta in deltas:
                omega = v * math.tan(delta) / self.wheelbase if delta != 0 else 0.0

                n_steps = _n_steps_for_control(spacing, angular_spacing, v, omega, cfg.DT)

                arr = arc_trajectory(x0, y0, h0, v, omega, n_steps, cfg.DT)

                traj = [CarState(row[0], row[1], row[2]) for row in arr]

                trajectories.append((traj, abs(v) * n_steps * cfg.DT))
        return trajectories

    def handle_input(self, state: CarState, speed: float) -> CarState:
        v, delta = 0.0, 0.0

        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP] and not keys[pygame.K_DOWN]:
            v = speed
        elif keys[pygame.K_DOWN] and not keys[pygame.K_UP]:
            v = -speed

        if keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT]:
            delta = -self.MAX_STEER
        elif keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]:
            delta = self.MAX_STEER

        return state.step(v, delta, self.wheelbase, cfg.DT)




# ── TrailerBot ────────────────────────────────────────────────────────────────

class TrailerBot(BotBase):
    """
    Truck-and-trailer system. The truck uses Ackermann steering; the trailer follows
    passively via hitch kinematics. Goal checking requires both truck and trailer headings
    to be within tolerance.
    """

    MAX_STEER       = math.radians(35)
    TERMINAL_RADIUS = 15.0
    JACKKNIFE_LIMIT = math.pi / 2  # max allowed angle between truck and trailer headings

    def __init__(
        self,
        wheelbase: float = cfg.TRUCK_WHEELBASE_METERS,
        length: float = cfg.TRUCK_LENGTH_METERS,
        width: float = cfg.TRUCK_WIDTH_METERS,
        hitch_distance: float = cfg.TRUCK_HITCH_TO_TRAILER_AXLE,
        trailer_length: float = cfg.TRAILER_LENGTH_METERS,
        trailer_width: float = cfg.TRAILER_WIDTH_METERS,
        goal_radius_tol: float = cfg.GOAL_RADIUS_TOLERANCE,
        goal_heading_tol: float = cfg.GOAL_HEADING_TOLERANCE,
        trailer_heading_tol: float = cfg.TRAILER_HEADING_TOLERANCE,
    ):
        self.wheelbase = wheelbase
        self.hitch_distance = hitch_distance
        self.turning_radius = wheelbase / math.tan(self.MAX_STEER)
        self.goal_radius_tol = goal_radius_tol
        self.goal_heading_tol = goal_heading_tol
        self.trailer_heading_tol = trailer_heading_tol
        self._truck_base = make_axle_rect_base(wheelbase, length, width)
        self._trailer_base = make_centered_rect_base(trailer_length, trailer_width)
        self._truck_cache = build_heading_cache(self._truck_base)
        self._trailer_cache = build_heading_cache(self._trailer_base)



    def footprint(self, state: TrailerState, approximate: bool = False) -> list[FootprintEntry]:
        if approximate:
            return truck_trailer_approximate(state, self.hitch_distance, self._truck_cache, self._trailer_cache)
        else:
            return truck_trailer_geom(state, self._truck_base, self._trailer_base, self.hitch_distance)

    def generate_trajectory(
        self, start: TrailerState, goal: TrailerState, resolution: float = 0.1
    ) -> list[TrailerState] | None:
        """Connect start to goal via a Reeds-Shepp path with trailer heading integrated along the way.

        The truck follows the RS path; the trailer heading is propagated using the
        hitch ODE at each step. Returns None if no RS path exists or if the path
        causes a jackknife.
        """
        raw = rs_path_sample(start.pose(), goal.pose(), self.turning_radius, resolution)
        if raw is None:
            return None

        phi    = start.trailer_heading_rad
        states: list[TrailerState] = [start]

        for i in range(1, len(raw)):
            x1, y1, theta  = raw[i][0], raw[i][1], raw[i][2]
            p0 = (raw[i-1][0], raw[i-1][1])

            length_sign  = math.copysign(1.0, raw[i][4])  # s[4] = signed segment length; sign = direction
            ds           = center_distance(Position((x1, y1)), Position(p0))

            # integrate trailer heading along arc (derived from TrailerState.step kinematics)
            phi += length_sign * math.sin(angle_difference(theta, phi)) * ds / self.hitch_distance

            if angle_distance(theta, phi) > self.JACKKNIFE_LIMIT:
                return None

            states.append(TrailerState(x1, y1, theta, phi))

        return states

    def propagate(self, state: TrailerState, spacing: float, angular_spacing: float, steering_granularity: int) -> list[tuple[list[TrailerState], float]]:
        deltas = [
            self.MAX_STEER * i / steering_granularity
            for i in range(-steering_granularity, steering_granularity + 1)
        ]
        x0, y0, h0 = state.rear_axle_x, state.rear_axle_y, state.heading_rad
        phi0 = state.trailer_heading_rad
        trajectories = []
        for v in (self.SPEED, -self.SPEED):
            for delta in deltas:
                omega = v * math.tan(delta) / self.wheelbase if delta != 0 else 0.0

                # the trailer runs into an issue where it is unable to generate straight primitives
                # without the + 1 here. To observe, comment it out and try to find a obstacle field
                # that doesn't allow the initial pose to generate any turning primitives. It will be
                # unable to find any path out. As of writing this comment, a seed of 27 should be good.

                # This is likely due to some weird floating point error, I did not consider it worth
                # debugging instead of just leaving it.
                n_steps = _n_steps_for_control(spacing,angular_spacing, v, omega, cfg.DT) + 1


                # truck trajectory is a circular arc — compute all states at once
                arr = arc_trajectory(x0, y0, h0, v, omega, n_steps, cfg.DT)

                # trailer heading (phi) is coupled to the truck via a nonlinear ODE and
                # must be integrated sequentially; only the scalar phi is tracked here,
                # not a full state object, so this loop is as cheap as possible
                traj: list[TrailerState] = [state]
                phi = phi0
                jackknifed = False
                for i in range(1, n_steps + 1):
                    phi += (v / self.hitch_distance) * math.sin(arr[i, 2] - phi) * cfg.DT

                    if angle_distance(arr[i, 2], phi) > self.JACKKNIFE_LIMIT:
                        jackknifed = True
                        break

                    traj.append(TrailerState(arr[i, 0], arr[i, 1], arr[i, 2], phi))

                if not jackknifed:
                    trajectories.append((traj, abs(v) * n_steps * cfg.DT))

        return trajectories

    def handle_input(self, state: TrailerState, speed: float) -> TrailerState:
        v, delta = 0.0, 0.0

        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP] and not keys[pygame.K_DOWN]:
            v = speed
        elif keys[pygame.K_DOWN] and not keys[pygame.K_UP]:
            v = -speed

        if keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT]:
            delta = -self.MAX_STEER
        elif keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]:
            delta = self.MAX_STEER

        return state.step(v, delta, self.wheelbase, self.hitch_distance, cfg.DT)
