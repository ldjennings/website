"""
Shared math and geometry utilities used across packages.
"""

import math

from wildfire.aliases import GridCell, WorldPos




def euclidean_distance(p1: WorldPos, p2: WorldPos) -> float:
    return math.hypot(p2[0] - p1[0], p2[1] - p1[1])

def grid_to_world(row: int, col: int, cell_size: float) -> WorldPos:
    """Convert grid (row, col) to world (x, y) at the cell center."""
    x = (col + 0.5) * cell_size
    y = (row + 0.5) * cell_size
    return (x, y)


def world_to_grid(x: float, y: float, cell_size: float) -> GridCell:
    """Convert world (x, y) to the containing grid (row, col)."""
    col = int(x // cell_size)
    row = int(y // cell_size)
    return (row, col)
