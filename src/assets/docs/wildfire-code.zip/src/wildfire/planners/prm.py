"""
Probabilistic RoadMap (PRM) planner for the firetruck.

Builds a roadmap of collision-free (x, y, heading) poses connected by
kinematically feasible trajectories, then answers point-to-point queries
with A* on the roadmap graph.
"""

import math
import heapq
from dataclasses import dataclass, field

import numpy as np
from scipy.spatial import KDTree

import wildfire.config as cfg
from wildfire.agents import TruckState, Firetruck, sample_random_state, is_valid_pose
from wildfire.environment import WildfireEnvironment

from wildfire.aliases import Pose, WorldPos
from wildfire.utils import euclidean_distance
from .postprocess import path_collision_free, smooth_path


# ── PRM node ─────────────────────────────────────────────────────────────

@dataclass(eq=False)
class PrmNode:
    """A single roadmap node with its outgoing edges."""
    pos:       WorldPos
    heading:   float
    neighbors: list[tuple["PrmNode", float]] = field(default_factory=list)

    @property
    def pose(self) -> Pose:
        return (*self.pos, self.heading)

# ── sampling ─────────────────────────────────────────────────────────────

def _sample_free_poses(
    env: WildfireEnvironment,
    truck: Firetruck,
    rng: np.random.Generator,
    num_samples: int,
) -> list[Pose]:
    """Rejection-sample collision-free (x, y, heading) poses for PRM nodes."""
    samples: list[Pose] = []
    attempts = 0
    while len(samples) < num_samples and attempts < num_samples * 20:
        state = sample_random_state(rng)
        if is_valid_pose(env, truck, state):
            samples.append((state.rear_axle_x, state.rear_axle_y, state.heading_rad))
        attempts += 1
    return samples


# ── PRM ──────────────────────────────────────────────────────────────────

class PRMPlanner:
    """
    Pose-based PRM planner.

    Nodes are PrmNode objects carrying their own neighbor lists.
    Roadmap is built at construction time.
    """

    # ── construction ─────────────────────────────────────────────────────

    def __init__(
        self,
        env: WildfireEnvironment,
        truck: Firetruck,
        num_samples:     int   = cfg.PRM_NUM_SAMPLES,
        k_neighbors:     int   = cfg.PRM_K_NEIGHBORS,
        max_edge_len:    float = cfg.PRM_MAX_EDGE_LEN,
        edge_resolution: float = 1.0,
        seed:            int   = 0,
    ) -> None:
        self._edge_resolution = edge_resolution
        self._rng = np.random.default_rng(seed)

        samples = _sample_free_poses(env, truck, self._rng, num_samples)
        assert len(samples) > 0, "PRM sampling produced zero valid nodes — increase field size or reduce obstacles"

        self.nodes = [PrmNode(pos=(x, y), heading=h) for x, y, h in samples]
        self._tree  = KDTree([n.pos for n in self.nodes])

        self._connect_nodes(env, truck, k_neighbors, max_edge_len, edge_resolution)

    def _connect_nodes(
        self,
        env: WildfireEnvironment,
        truck: Firetruck,
        k_neighbors: int,
        max_edge_len: float,
        edge_resolution: float,
    ) -> None:
        """
        For each node, attempt to connect its k nearest spatial neighbors via
        a collision-free trajectory. Edges are added only when the path length
        is within max_edge_len and clears obstacles.
        """
        for node_i in self.nodes:
            for node_j in self.k_nearest_nodes(node_i.pose, k_neighbors + 1):
                if node_i is node_j:
                    continue
                length = truck.trajectory_length(node_i.pose, node_j.pose)
                if length > max_edge_len:
                    continue
                path = truck.generate_trajectory(node_i.pose, node_j.pose, edge_resolution)
                if path is not None and path_collision_free(env, truck, path, 1):
                    node_i.neighbors.append((node_j, length))

    # ── public interface ──────────────────────────────────────────────────

    def query(
        self,
        start: TruckState,
        goal_xy: WorldPos,
        env: WildfireEnvironment,
        truck: Firetruck,
    ) -> list[TruckState] | None:
        """Find a kinematically feasible path from start to goal_xy, or None."""
        start_pose = (start.rear_axle_x, start.rear_axle_y, start.heading_rad)

        s_node = self._connect_to_roadmap(start_pose, env, truck)
        if s_node is None:
            return None

        goal_pose, g_node = self._escapable_goal_pose(goal_xy, env, truck)
        if g_node is None:
            return None

        node_path = self._prm_astar(s_node, g_node)
        if node_path is None:
            return None

        return self._build_full_path(start_pose, node_path, goal_pose, env, truck)

    # ── roadmap ───────────────────────────────────────────────────────────

    def k_nearest_nodes(self, pose: Pose, k: int) -> list[PrmNode]:
        """Return up to k roadmap nodes nearest to pose, sorted by distance."""
        _, idxs = self._tree.query(pose[:2], k=min(k, len(self.nodes)))
        return [self.nodes[int(j)] for j in np.atleast_1d(idxs)]

    def _connect_to_roadmap(
        self,
        pose: Pose,
        env: WildfireEnvironment,
        truck: Firetruck,
        k: int = 15,
    ) -> PrmNode | None:
        """Find the nearest roadmap node reachable via a collision-free trajectory."""
        for node in self.k_nearest_nodes(pose, k):
            path = truck.generate_trajectory(pose, node.pose, self._edge_resolution)
            if path is not None and path_collision_free(env, truck, path, 1):
                return node
        return None
    
    def _escapable_goal_pose(
        self,
        goal_xy: WorldPos,
        env: WildfireEnvironment,
        truck: Firetruck,
    ) -> tuple[Pose, PrmNode | None]:
        """
        Try 8 evenly-spaced headings at goal_xy and return the first pose that
        can connect back to the roadmap, together with the connecting node.
        Ensures the truck will not park itself in an inescapable configuration.
        Returns (pose, None) if no heading works.
        """
        for i in range(8):
            heading = i * math.pi / 4
            pose: Pose = (*goal_xy, heading)
            node = self._connect_to_roadmap(pose, env, truck)
            if node is not None:
                return pose, node
        return (*goal_xy, 0.0), None

    # ── graph search ──────────────────────────────────────────────────────

    def _prm_astar(self, start: PrmNode, goal: PrmNode) -> list[PrmNode] | None:
        g_score: dict[PrmNode, float] = {start: 0.0}
        came_from: dict[PrmNode, PrmNode] = {}
        open_set: list[tuple[float, PrmNode]] = [(0.0, start)]

        while open_set:
            _, current = heapq.heappop(open_set)
            if current == goal:
                path = [current]
                cur = current
                while cur in came_from:
                    cur = came_from[cur]
                    path.append(cur)
                path.reverse()
                return path

            for neighbor, cost in current.neighbors:
                tentative_g = g_score[current] + cost
                if tentative_g < g_score.get(neighbor, float("inf")):
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f = tentative_g + euclidean_distance(neighbor.pos, goal.pos)
                    heapq.heappush(open_set, (f, neighbor))

        return None

    # ── trajectory ────────────────────────────────────────────────────────

    def _build_full_path(
        self,
        start_pose: Pose,
        node_path: list[PrmNode],
        goal_pose: Pose,
        env: WildfireEnvironment,
        truck: Firetruck,
    ) -> list[TruckState] | None:
        """
        Stitch together trajectory segments: start→nodes[0]→...→goal,
        then smooth via random shortcutting.
        Returns the full dense path, or None if any segment fails.
        """
        full_path: list[TruckState] = []
        resolution = 0.5

        poses = [start_pose] + [n.pose for n in node_path] + [goal_pose]

        for a, b in zip(poses, poses[1:]):
            seg = truck.generate_trajectory(a, b, resolution)
            if seg is None:
                return None
            if full_path:
                seg = seg[1:]
            full_path.extend(seg)

        if not full_path:
            return None

        return smooth_path(full_path, env, truck, self._rng, max_iterations=200)
