"""
Shared type aliases for the wildfire package.
"""

from typing import TypeAlias
from shapely.geometry.base import BaseGeometry


# World-space (x, y) position in meters
WorldPos: TypeAlias = tuple[float, float]

# Grid cell address as (row, col).
GridCell: TypeAlias = tuple[int, int]

# Continuous world-space pose: (x, y, heading_rad)
Pose: TypeAlias = tuple[float, float, float]

# Axis-aligned bounding box: (min_x, min_y, max_x, max_y) — Shapely convention
BoundingBox: TypeAlias = tuple[float, float, float, float]

# One collision geometry entry returned by agent.footprint()
# (x_offset, y_offset, geometry, bounds)
# offset is (0, 0) for exact placement; (x, y) for approximate (pre-rotated only)
FootprintEntry: TypeAlias = tuple[float, float, BaseGeometry, BoundingBox]

# Full collision footprint: the list returned by agent.footprint()
Footprint: TypeAlias = list[FootprintEntry]

# Ordered sequence of grid cells (A* path result)
GridPath: TypeAlias = list[GridCell]
