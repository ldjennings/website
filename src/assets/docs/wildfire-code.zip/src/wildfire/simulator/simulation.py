"""
Main simulation loop.

Orchestrates the environment, agents, planners, rendering, and scoring.
Each call to run() executes one full 3600-second simulation.
"""

import time
from dataclasses import dataclass

import pygame

import wildfire.config as cfg
from wildfire.environment import WildfireEnvironment
from wildfire.agents import Firetruck, Wumpus, TruckState
from wildfire.planners import PRMPlanner
from .renderer import Renderer
from .recorder import MP4Recorder, NoOpRecorder


@dataclass
class SimulationResult:
    seed:                int
    wumpus_score:        int
    truck_score:         int
    wumpus_plan_time_s:  float
    truck_plan_time_s:   float


class Simulation:

    def __init__(self, seed: int = 0) -> None:
        self._seed = seed
        self._env = WildfireEnvironment(seed)

        # truck in bottom-left, facing right
        self._truck = Firetruck(
            start_x=cfg.CELL_SIZE * 1.5,
            start_y=cfg.FIELD_SIZE - cfg.CELL_SIZE * 1.5,
            heading=0.0,
        )

        # wumpus in top-right
        self._wumpus = Wumpus(
            start_row=1,
            start_col=cfg.GRID_SIZE - 2,
        )

        self._prm: PRMPlanner  # built at the start of run()
        self._wumpus_plan_time = 0.0
        self._truck_plan_time  = 0.0
        self._sim_time = 0.0
        self._last_truck_target_check: float = -cfg.TRUCK_TARGET_CHECK_INTERVAL

    # ── public interface ─────────────────────────────────────────────────

    def run(self, render: bool = True, record: bool = False) -> SimulationResult:
        """
        Run one full simulation and return the result.

        Args:
            render: Show the pygame window. Disable for faster headless runs.
            record: Save the run as recording.mp4. Ignored when render=False.
        """
        t0 = time.perf_counter()
        self._prm = PRMPlanner(self._env, self._truck, seed=self._seed)
        self._truck_plan_time += time.perf_counter() - t0
        print(f"  PRM built: {len(self._prm.nodes)} nodes, "
              f"{sum(len(n.neighbors) for n in self._prm.nodes)} edges  "
              f"({self._truck_plan_time:.2f}s)")

        if render:
            self._run_rendered(record)
        else:
            self._run_headless()

        return self._result()

    # ── simulation loops ─────────────────────────────────────────────────

    def _run_headless(self) -> None:
        while self._sim_time < cfg.SIM_DURATION:
            self._step()
            if self._env.is_steady_state():
                print(f"  Steady state reached at t={self._sim_time:.1f}s")
                break

    def _run_rendered(self, record: bool = False) -> None:
        renderer = Renderer()
        clock = pygame.time.Clock()
        recorder = MP4Recorder() if record else NoOpRecorder()
        sim_speed = 10

        while self._sim_time < cfg.SIM_DURATION:
            for _ in range(sim_speed):
                self._step()
                if self._sim_time >= cfg.SIM_DURATION:
                    break
                if self._env.is_steady_state():
                    print(f"  Steady state reached at t={self._sim_time:.1f}s")
                    self._sim_time = cfg.SIM_DURATION
                    break

            quit_requested, sim_speed = self._handle_events(renderer, sim_speed)
            if quit_requested:
                break

            ws, ts = self._env.compute_scores()
            renderer.render(
                self._env, self._truck, self._wumpus,
                prm=self._prm,
                truck_path=self._truck.current_path,
                sim_time=self._sim_time,
                wumpus_score=ws, truck_score=ts,
            )
            recorder.capture(renderer.screen)
            clock.tick(30)

        recorder.save()
        pygame.quit()

    def _handle_events(self, renderer: Renderer, sim_speed: int) -> tuple[bool, int]:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return True, sim_speed
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_EQUALS, pygame.K_PLUS):
                    sim_speed = min(200, sim_speed * 2)
                    print(f"  speed: {sim_speed}x")
                elif event.key == pygame.K_MINUS:
                    sim_speed = max(1, sim_speed // 2)
                    print(f"  speed: {sim_speed}x")
                elif event.key == pygame.K_s:
                    path = renderer.screenshot()
                    print(f"  screenshot saved: {path}")
        return False, sim_speed

    # ── per-tick logic ───────────────────────────────────────────────────

    def _step(self) -> None:
        dt = cfg.SIM_DT
        self._sim_time += dt

        self._env.update_fires(self._sim_time)

        truck_pos = (self._truck.state.rear_axle_x, self._truck.state.rear_axle_y)

        t0 = time.perf_counter()
        self._wumpus.update(self._env, dt, self._sim_time, truck_pos)
        self._wumpus_plan_time += time.perf_counter() - t0

        t0 = time.perf_counter()
        self._update_truck(dt)
        self._truck_plan_time += time.perf_counter() - t0

    
    def _update_truck(self, dt: float) -> None:
        if self._truck.has_path():
            self._truck.follow_path(dt)
            return

        if self._truck.try_extinguish(self._env, dt):
            return

        if self._should_check_target():
            targets = self._truck.choose_targets(self._env)
            path = self._plan_to_target(targets)
            if path:
                self._truck.set_path(path)

    def _plan_to_target(self, targets: list) -> list[TruckState] | None:
        for goal, _ in targets[:cfg.TRUCK_MAX_QUERY_ATTEMPTS]:
            path = self._prm.query(self._truck.state, goal, self._env, self._truck)
            if path:
                return path
        return None

    def _should_check_target(self) -> bool:
        """True once per TRUCK_TARGET_CHECK_INTERVAL seconds."""
        if self._sim_time - self._last_truck_target_check >= cfg.TRUCK_TARGET_CHECK_INTERVAL:
            self._last_truck_target_check = self._sim_time
            return True
        return False

    # ── results ──────────────────────────────────────────────────────────

    def _result(self) -> SimulationResult:
        ws, ts = self._env.compute_scores()
        return SimulationResult(
            seed=self._seed,
            wumpus_score=ws,
            truck_score=ts,
            wumpus_plan_time_s=self._wumpus_plan_time,
            truck_plan_time_s=self._truck_plan_time,
        )
