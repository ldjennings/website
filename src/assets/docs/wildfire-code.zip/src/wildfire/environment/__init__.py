"""
World environment: obstacle field generation and fire-state management.
"""
from .obstacles import WildfireEnvironment, Obstacle, ObstacleState
