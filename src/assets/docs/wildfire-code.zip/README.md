# Wildfire — RBE 550 Motion Planning

Competitive wildfire simulation between two autonomous agents. The **Wumpus** navigates a grid igniting obstacles using discrete A\*; the **Firetruck** pursues and extinguishes fires using a Probabilistic RoadMap (PRM) with Reeds-Shepp local connections under Ackermann kinematic constraints.

## Requirements

- Python 3.12+
- A C++ compiler (GCC or Clang) and the Boost headers — needed to build the bundled `reeds_shepp` extension

Install Boost headers:

```sh
# Debian/Ubuntu
sudo apt install libboost-dev

# macOS
brew install boost

# Fedora/RHEL
sudo dnf install boost-devel
```

The Reeds-Shepp library is vendored under `deps/pyReedsShepp` and built automatically during installation.

## Installation

### With uv (recommended)

[uv](https://docs.astral.sh/uv/) handles virtual environment creation and dependency resolution automatically:

```sh
uv sync
```

### Without uv

```sh
python3.12 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

pip install -e deps/pyReedsShepp  # build and install the Reeds-Shepp extension
pip install -e .
```

## Usage

```sh
uv run runsim [options]
```

| Flag | Effect |
|---|---|
| `--no-render` | Run headless (no pygame window). Faster for batch runs. |
| `--iterations N` | Number of simulation runs (default: 5). |
| `--seed N` | Base RNG seed; run *i* uses seed + *i* (default: random). |
| `--record` | Save the first iteration as `recording.mp4`. |

### Examples

```sh
# run 5 iterations headless with a fixed seed
uv run runsim --no-render --seed 42

# single rendered run
uv run runsim --iterations 1

# record the first run
uv run runsim --iterations 1 --record
```

### Keyboard shortcuts (rendered mode)

| Key | Effect |
|---|---|
| `+` / `=` | Double simulation speed (up to 200×) |
| `-` | Halve simulation speed |
| `s` | Save a screenshot |

## Output

Each run prints per-iteration scores and planning times to stdout. After all iterations complete, a summary table and `cpu_times.png` (cumulative planning time bar chart) are saved to the project root.

## Project Structure

```
src/wildfire/
  agents/       Firetruck and Wumpus agent logic
  environment/  Obstacle field, fire mechanics, collision detection
  planners/     PRM, grid A*, path post-processing
  simulator/    Main loop, renderer, recorder
  config.py     All tunable simulation parameters
deps/           Vendored dependencies (pyReedsShepp)
report/         Typst report source and figures
```
