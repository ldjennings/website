"""
Entry point for the wildfire simulation.

Usage:
    runsim                     # 5 iterations, rendering enabled
    runsim --no-render         # headless (faster)
    runsim --iterations 1      # single run
    runsim --record            # save first iteration as recording.mp4
    runsim --seed 42           # reproducible obstacle fields
"""

import argparse
import random
import matplotlib.pyplot as plt

import wildfire.config as cfg
from wildfire.simulator import Simulation, SimulationResult


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="runsim",
        description="Wildfire simulation for RBE-550",
    )
    p.add_argument("--no-render", action="store_true",
                   help="Run headless (no pygame window)")
    p.add_argument("--record", action="store_true",
                   help="Save first iteration as recording.mp4 (requires rendering)")
    p.add_argument("--iterations", type=int, default=cfg.NUM_ITERATIONS,
                   help="Number of simulation runs")
    p.add_argument("--seed", type=int, default=random.randint(0, 2**32),
                   help="Base random seed")
    return p.parse_args()


def print_results_table(results: list[SimulationResult]) -> None:
    print()
    print(f"{'Run':>4}  {'Seed':>10}  {'Wumpus':>7}  {'Truck':>7}  {'Winner':>8}  "
          f"{'W-plan(s)':>10}  {'T-plan(s)':>10}")
    print("-" * 72)

    w_wins = 0
    t_wins = 0
    for i, r in enumerate(results):
        if r.wumpus_score > r.truck_score:
            winner = "Wumpus"
            w_wins += 1
        elif r.truck_score > r.wumpus_score:
            winner = "Truck"
            t_wins += 1
        else:
            winner = "Tie"
        print(f"{i+1:>4}  {r.seed:>6}  {r.wumpus_score:>7}  {r.truck_score:>7}  "
              f"{winner:>8}  {r.wumpus_plan_time_s:>10.3f}  {r.truck_plan_time_s:>10.3f}")

    print("-" * 72)
    champion = "Wumpus" if w_wins > t_wins else "Truck" if t_wins > w_wins else "Tie"
    print(f"  Champion: {champion}  (Wumpus {w_wins} - Truck {t_wins})")
    print()


def plot_cpu_times(results: list[SimulationResult], out: str = "cpu_times.png") -> None:
    """Bar chart of cumulative planning CPU time per player."""
    wumpus_total = sum(r.wumpus_plan_time_s for r in results)
    truck_total  = sum(r.truck_plan_time_s for r in results)

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(["Wumpus (A*)", "Truck (PRM)"], [wumpus_total, truck_total],
           color=["#800080", "#1E64C8"])
    ax.set_ylabel("CPU time (seconds)")
    ax.set_title("Cumulative Planning Time")
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print(f"Saved CPU-time plot to {out}")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    render = not args.no_render
    seed = args.seed
    iterations = args.iterations

    results: list[SimulationResult] = []

    for i in range(iterations):
        s = seed + i
        print(f"\n{'=' * 60}")
        print(f"  Iteration {i + 1}/{iterations}  (seed={s})")
        print(f"{'=' * 60}")

        sim = Simulation(seed=s)
        result = sim.run(
            render=render,
            record=(args.record and i == 0),
        )
        results.append(result)

        print(f"  Wumpus: {result.wumpus_score}  |  Truck: {result.truck_score}")

    print_results_table(results)
    plot_cpu_times(results)


if __name__ == "__main__":
    main()
