"""
Pygame renderer for the wildfire simulation.
"""

import datetime
import pygame
import pygame.gfxdraw
import numpy as np

import wildfire.config as cfg
from wildfire.aliases import WorldPos
from wildfire.environment import WildfireEnvironment, ObstacleState



def scale(points, s=cfg.METERS_TO_PIXELS):
    """Convert meter coordinates to pixel coordinates."""
    return (np.array(points) * s).tolist()


def draw_shape(surface: pygame.Surface, geom, color, outline: bool = False, outline_color=None):
    """Render a Shapely geometry onto a pygame surface."""
    if geom.geom_type == "Polygon":
        coords = scale(list(geom.exterior.coords))
        pygame.draw.polygon(surface, color, coords, 0)
        if outline:
            oc = outline_color or color
            pygame.gfxdraw.aapolygon(surface, coords, oc)
    elif geom.geom_type == "Point":
        x, y = scale(list(geom.coords))[0]
        pygame.draw.circle(surface, color, (int(x), int(y)), 3)
    elif geom.geom_type in ("MultiPolygon", "GeometryCollection"):
        for g in geom.geoms:
            draw_shape(surface, g, color, outline, outline_color)


# ── obstacle state → color ───────────────────────────────────────────────

_STATE_COLORS = {
    ObstacleState.INTACT:       cfg.DARK_GREEN,
    ObstacleState.BURNING:      cfg.ORANGE,
    ObstacleState.EXTINGUISHED: cfg.GRAY,
    ObstacleState.BURNED:       cfg.BROWN,
}

_STATE_OUTLINES = {
    ObstacleState.BURNING: cfg.RED,
}


def draw_environment(surface: pygame.Surface, env: WildfireEnvironment) -> None:
    """Draw the full obstacle field with state-based coloring."""
    s = cfg.METERS_TO_PIXELS
    cs = cfg.CELL_SIZE

    draw_shape(surface, env.enclosure, cfg.WHITE, True)
    for (r, c), obs in env.obstacle_map.items():
        color   = _STATE_COLORS.get(obs.state, cfg.DARK_GREEN)
        outline = _STATE_OUTLINES.get(obs.state)
        rect = pygame.Rect(int(c * cs * s), int(r * cs * s),
                           int(cs * s), int(cs * s))
        pygame.draw.rect(surface, color, rect)
        if outline:
            pygame.draw.rect(surface, outline, rect, 1)


def draw_wumpus(surface: pygame.Surface, world_x: float, world_y: float) -> None:
    """Draw the Wumpus as a filled circle."""
    px = int(world_x * cfg.METERS_TO_PIXELS)
    py = int(world_y * cfg.METERS_TO_PIXELS)
    pygame.draw.circle(surface, cfg.PURPLE, (px, py), 6)
    pygame.draw.circle(surface, cfg.BLACK, (px, py), 6, 1)


def draw_truck(surface: pygame.Surface, footprint) -> None:
    """Draw the firetruck's collision polygon."""
    for _, _, geom, _ in footprint:
        draw_shape(surface, geom, cfg.BLUE, outline=True, outline_color=cfg.BLACK)


def draw_path(surface: pygame.Surface, path: list[WorldPos], color=cfg.LIGHT_BLUE) -> None:
    """Draw a waypoint path as connected line segments."""
    if len(path) < 2:
        return
    points = [(int(x * cfg.METERS_TO_PIXELS), int(y * cfg.METERS_TO_PIXELS))
              for x, y in path]
    pygame.draw.lines(surface, color, False, points, 1)


def draw_roadmap(surface: pygame.Surface, prm) -> None:
    """Draw PRM nodes and edges (thin gray lines)."""
    s = cfg.METERS_TO_PIXELS
    for node in prm.nodes:
        px, py = int(node.pos[0] * s), int(node.pos[1] * s)
        pygame.draw.circle(surface, cfg.GRAY, (px, py), 1)
        for neighbor, _ in node.neighbors:
            pygame.draw.line(surface, (200, 200, 200),
                             (px, py), (int(neighbor.pos[0] * s), int(neighbor.pos[1] * s)), 1)



class Renderer:
    """
    Manages the pygame display and draws each frame.

    Call render() once per visual frame.  The simulation may advance
    many timesteps between render calls (controlled by sim_speed).
    """

    def __init__(self) -> None:
        pygame.init()
        self.screen = pygame.display.set_mode(cfg.VIRTUAL_SIZE, pygame.RESIZABLE)
        self.surface = pygame.Surface(cfg.VIRTUAL_SIZE)
        pygame.display.set_caption("Wildfire Simulation")
        self.font = pygame.font.SysFont("monospace", 14)

    def render(self, env, truck, wumpus, prm=None,
               truck_path=None, sim_time: float = 0.0,
               wumpus_score: int = 0, truck_score: int = 0) -> None:


        # field boundary
        s = cfg.METERS_TO_PIXELS
        pygame.draw.rect(self.surface, cfg.BLACK,
                         (0, 0, int(cfg.FIELD_SIZE * s), int(cfg.FIELD_SIZE * s)), 1)

        # obstacles
        draw_environment(self.surface, env)

        # roadmap (behind everything)
        if prm is not None:
            draw_roadmap(self.surface, prm)

        # truck path (convert TruckState list to (x,y) list)
        if truck_path:
            xy_path = [(s.rear_axle_x, s.rear_axle_y) for s in truck_path]
            draw_path(self.surface, xy_path)

        # agents
        draw_truck(self.surface, truck.footprint())
        wx, wy = wumpus.state.world_pos
        draw_wumpus(self.surface, wx, wy)

        # HUD
        self._draw_hud(sim_time, wumpus_score, truck_score)

        # blit to screen (handles window resize)
        self._blit()
        pygame.display.flip()

    def _draw_hud(self, sim_time, ws, ts):
        lines = [
            f"t={sim_time:7.1f}s",
            f"Wumpus: {ws}",
            f"Truck:  {ts}",
        ]
        y = 4
        for line in lines:
            img = self.font.render(line, True, cfg.BLACK)
            self.surface.blit(img, (4, y))
            y += 16

    def screenshot(self) -> str:
        """Save the current frame to a timestamped PNG. Returns the file path."""
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = f"screenshot_{ts}.png"
        pygame.image.save(self.screen, path)
        return path

    def _blit(self):
        ww, wh = self.screen.get_size()
        vw, vh = cfg.VIRTUAL_SIZE
        scale = min(ww / vw, wh / vh)
        scaled = pygame.transform.smoothscale(
            self.surface, (int(vw * scale), int(vh * scale))
        )
        ox = (ww - scaled.get_width()) // 2
        oy = (wh - scaled.get_height()) // 2
        self.screen.fill(cfg.BLACK)
        self.screen.blit(scaled, (ox, oy))
