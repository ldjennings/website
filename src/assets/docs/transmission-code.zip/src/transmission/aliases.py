# (x, y, z, theta, phi) — 5-DOF mainshaft pose
#   x, y, z:     centroid position in mm
#   theta:       polar angle from +Z in [0, pi]
#   phi:         azimuthal angle from +X in [0, 2*pi]
type ShaftPose = tuple[float, float, float, float, float]
