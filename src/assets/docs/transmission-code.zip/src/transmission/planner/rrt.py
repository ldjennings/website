"""
Bidirectional RRT (BiRRT) planner for SM-465 mainshaft removal.
"""

import time
import numpy as np
from dataclasses import dataclass


from transmission.aliases import ShaftPose
from transmission.config import MAINSHAFT_LENGTH
from transmission.state_utils import (
    pose_distance, sample_random_pose, step_toward, PoseBounds,
)
from transmission.environment import TransmissionCollisionChecker
from transmission.planner.postprocessing import smooth_path


# =============================================================================
# Tree data structure
# =============================================================================

@dataclass
class RRTNode:
    pose:   ShaftPose
    parent: "RRTNode | None" = None


class RRTTree:
    def __init__(self, root_pose: ShaftPose):
        self.nodes: list[RRTNode] = [RRTNode(root_pose, None)]

    def add(self, pose: ShaftPose, parent: RRTNode) -> RRTNode | None:
        if parent in self.nodes:
            n = RRTNode(pose=pose, parent=parent)
            self.nodes.append(n)
            return n
        return None

    def nearest(self, pose: ShaftPose, w_rot: float = MAINSHAFT_LENGTH / 2) -> RRTNode:
        return min(self.nodes, key=lambda n: pose_distance(n.pose, pose, w_rot))

    def random(self, rng: np.random.Generator) -> RRTNode:
        return self.nodes[rng.integers(0, len(self.nodes))]

    def path_to_root(self, node: RRTNode) -> list[ShaftPose]:
        if node not in self.nodes:
            return []
        path, curr = [node.pose], node.parent
        while curr is not None:
            path.append(curr.pose)
            curr = curr.parent
        path.reverse()
        return path


# =============================================================================
# Planner configuration and result
# =============================================================================

@dataclass
class PlannerConfig:
    """Tuning parameters for the BiRRT planner."""
    max_iterations: int   = 20000
    step_size:      float = 30.0   # max position step (mm)
    step_size_rot:  float = 0.15   # max rotation step (rad, ~8.6°)
    connect_radius: float = 50.0   # distance threshold for tree connection
    edge_checks:    int   = 8      # collision samples per edge
    seed:           int   = 42
    w_rot:          float = MAINSHAFT_LENGTH / 2  # arc length at shaft tip (mm/rad)


@dataclass
class PlanResult:
    path:          list[ShaftPose]
    smooth_path:   list[ShaftPose]
    tree_start:    RRTTree
    tree_goal:     RRTTree
    iterations:    int
    planning_time: float  # seconds


# =============================================================================
# BiRRT helpers
# =============================================================================


def _extend(active: RRTTree, q_rand: ShaftPose,
            checker: TransmissionCollisionChecker,
            pc: PlannerConfig) -> RRTNode | None:
    """Extend active tree one step toward q_rand. Returns the new node, or None if blocked."""
    q_near   = active.nearest(q_rand, pc.w_rot)
    new_pose = step_toward(q_near.pose, q_rand, pc.step_size, pc.step_size_rot)

    if checker.check_collision(new_pose):
        return None
    if not checker.check_path_segment(q_near.pose, new_pose, pc.edge_checks):
        return None

    return active.add(new_pose, q_near)


def _can_connect(p1: ShaftPose, p2: ShaftPose,
                 checker: TransmissionCollisionChecker,
                 pc: PlannerConfig) -> bool:
    """True if p1 and p2 are within connect_radius and the edge between them is collision-free."""
    dist = pose_distance(p1, p2, pc.w_rot)
    if dist >= pc.connect_radius:
        return False
    return checker.check_path_segment(p1, p2, pc.edge_checks)


def _connect(target: RRTTree, from_pose: ShaftPose,
             checker: TransmissionCollisionChecker,
             pc: PlannerConfig) -> RRTNode | None:
    """
    Try to connect the target tree to from_pose.

    If the nearest target node is already within connect_radius, attempts a direct
    connection. Otherwise greedily extends the target tree toward from_pose until
    an obstacle is hit or a connection is made.
    """
    nearest = target.nearest(from_pose, pc.w_rot)
    if _can_connect(from_pose, nearest.pose, checker, pc):
        return nearest

    while True:
        new_node = _extend(target, from_pose, checker, pc)
        if new_node is None:
            break
        if _can_connect(new_node.pose, from_pose, checker, pc):
            return new_node

    return None


def _assemble_path(active: RRTTree, target: RRTTree,
                   active_node: RRTNode, target_node: RRTNode,
                   tree_start: RRTTree) -> list[ShaftPose]:
    path_active = active.path_to_root(active_node)
    path_target = target.path_to_root(target_node)
    if active is tree_start:
        return path_active + list(reversed(path_target))
    else:
        return path_target + list(reversed(path_active))


def _finish(active: RRTTree, target: RRTTree,
            active_node: RRTNode, target_node: RRTNode,
            tree_start: RRTTree, tree_goal: RRTTree,
            iteration: int, t_start: float,
            checker: TransmissionCollisionChecker,
            pc: PlannerConfig) -> PlanResult:
    elapsed  = time.time() - t_start
    raw_path = _assemble_path(active, target, active_node, target_node, tree_start)
    print(f"  Path found at iteration {iteration+1} ({elapsed:.1f}s)")

    print("\nSmoothing...")
    smoothed = smooth_path(raw_path, checker, rng=np.random.default_rng(pc.seed))
    print(f"  {len(raw_path)} waypoints → {len(smoothed)}")

    return PlanResult(
        path          = raw_path,
        smooth_path   = smoothed,
        tree_start    = tree_start,
        tree_goal     = tree_goal,
        iterations    = iteration + 1,
        planning_time = elapsed,
    )


# =============================================================================
# BiRRT
# =============================================================================

def plan_birrt(checker: TransmissionCollisionChecker,
               start: ShaftPose, goal: ShaftPose,
               pc: PlannerConfig) -> PlanResult | None:
    """
    Run BiRRT and return a smoothed PlanResult, or None if planning fails.

    based on:
    Kuffner, James & LaValle, Steven. (2000).
    RRT-Connect: An Efficient Approach to Single-Query Path Planning.
    Proceedings - IEEE International Conference on Robotics and Automation. 2. 995-1001.
    10.1109/ROBOT.2000.844730.
    """
    if checker.check_collision(start):
        print("ERROR: start pose is in collision:")
        print(checker.check_collision_detailed(start))
        return None
    if checker.check_collision(goal):
        print("ERROR: goal pose is in collision:")
        print(checker.check_collision_detailed(goal))
        return None

    rng        = np.random.default_rng(pc.seed)
    bounds     = PoseBounds()
    t_start    = time.time()
    start_tree = RRTTree(start)
    goal_tree  = RRTTree(goal)

    for iteration in range(pc.max_iterations):
        if (iteration + 1) % 1000 == 0:
            elapsed = time.time() - t_start
            print(f"  Iter {iteration+1}/{pc.max_iterations} "
                  f"({elapsed:.1f}s, trees: {len(start_tree.nodes)}+{len(goal_tree.nodes)})")

        active, target = (start_tree, goal_tree) if iteration % 2 == 0 \
                    else (goal_tree,  start_tree)

        q_rand   = sample_random_pose(bounds, rng)
        new_node = _extend(active, q_rand, checker, pc)

        if new_node is None:
            continue

        conn_node = _connect(target, new_node.pose, checker, pc)
        if conn_node is not None:
            return _finish(active, target, new_node, conn_node,
                           start_tree, goal_tree, iteration, t_start, checker, pc)

    print(f"  No path found after {pc.max_iterations} iterations")
    return None
