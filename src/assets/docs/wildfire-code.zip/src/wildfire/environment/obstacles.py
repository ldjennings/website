"""
Obstacle field with fire-state management.

Each grid cell that is occupied becomes an Obstacle with a state machine:
    intact -> burning -> burned      (fire runs its course)
    burning -> extinguished           (firetruck puts it out)
Fire spreads from burning obstacles to intact neighbors within a radius
after a configurable delay.
"""

import math
from enum import Enum, auto
from dataclasses import dataclass, field

import numpy as np
from shapely import STRtree
from shapely.affinity import translate
from shapely.geometry import box
from shapely.geometry.base import BaseGeometry

import wildfire.config as cfg
from .grid import populate_grid
from wildfire.aliases import Footprint, GridCell, WorldPos
from wildfire.utils import grid_to_world, euclidean_distance


class ObstacleState(Enum):
    INTACT       = auto()
    BURNING      = auto()
    EXTINGUISHED = auto()
    BURNED       = auto()


@dataclass
class Obstacle:
    """Mutable obstacle with fire-state tracking."""
    grid_row: int
    grid_col: int
    state: ObstacleState = ObstacleState.INTACT
    burn_start_time: float | None = None
    has_spread: bool = False
    wumpus_ignited: bool = False

    @property
    def center(self) -> WorldPos:
        """World-space center (x, y) of this obstacle cell."""
        return grid_to_world(self.grid_row, self.grid_col, cfg.CELL_SIZE)


class WildfireEnvironment:
    """
    250 m square field filled with tetromino obstacles.

    Provides collision queries (grid-based fast path + STRtree precise path)
    and fire-state bookkeeping used by the simulation loop.
    """

    def __init__(self, seed: int = 0) -> None:
        rng = np.random.default_rng(seed)
        shape = (cfg.GRID_SIZE, cfg.GRID_SIZE)

        raw = populate_grid(shape, cfg.OBSTACLE_COVERAGE, rng)

        # Clear corners for start positions
        clearance = 4
        raw[-clearance:, :clearance] = 0   # bottom-left  (truck)
        raw[:clearance, -clearance:] = 0   # top-right     (wumpus)

        self.grid: np.ndarray = raw.astype(np.bool_)

        # Build per-cell Obstacle objects and collision geometry
        self.obstacle_map: dict[GridCell, Obstacle] = {}
        polys: list[BaseGeometry] = []

        for r in range(shape[0]):
            for c in range(shape[1]):
                if self.grid[r, c]:
                    self.obstacle_map[(r, c)] = Obstacle(r, c)
                    polys.append(box(
                        c * cfg.CELL_SIZE, r * cfg.CELL_SIZE,
                        (c + 1) * cfg.CELL_SIZE, (r + 1) * cfg.CELL_SIZE,
                    ))

        self.collision_tree = STRtree(polys)
        self.enclosure = box(0, 0, cfg.FIELD_SIZE, cfg.FIELD_SIZE)
        self._bounds = (0.0, 0.0, float(cfg.FIELD_SIZE), float(cfg.FIELD_SIZE))

    # ── fire mechanics ───────────────────────────────────────────────────

    def update_fires(self, current_time: float) -> None:
        """Advance fire spread and burnout for all obstacles."""
        to_ignite: list[tuple[Obstacle, float]] = []

        for obs in self.obstacle_map.values():
            if obs.state != ObstacleState.BURNING:
                continue
            assert obs.burn_start_time is not None
            elapsed = current_time - obs.burn_start_time

            # spread after FIRE_SPREAD_TIME
            if not obs.has_spread and elapsed >= cfg.FIRE_SPREAD_TIME:
                obs.has_spread = True
                if obs.wumpus_ignited:
                    # radius explosion
                    for other in self.obstacle_map.values():
                        if other.state == ObstacleState.INTACT and euclidean_distance(obs.center, other.center) <= cfg.FIRE_SPREAD_RADIUS:
                            to_ignite.append((other, current_time))
                else:
                    # creep to adjacent grid cells
                    for dr, dc in WildfireEnvironment._8_CONNECTED_OFFSETS:
                        other = self.obstacle_map.get((obs.grid_row + dr, obs.grid_col + dc))
                        if other is not None and other.state == ObstacleState.INTACT:
                            to_ignite.append((other, current_time))

            # burn out
            if elapsed >= cfg.BURN_DURATION:
                obs.state = ObstacleState.BURNED
                
        for obs, t in to_ignite:
            if obs.state == ObstacleState.INTACT:
                obs.state = ObstacleState.BURNING
                obs.burn_start_time = t

    def ignite(self, row: int, col: int, current_time: float) -> bool:
        """Set an intact obstacle to burning. Returns True on success."""
        obs = self.obstacle_map.get((row, col))
        if obs is not None and obs.state == ObstacleState.INTACT:
            obs.state = ObstacleState.BURNING
            obs.burn_start_time = current_time
            obs.wumpus_ignited = True
            return True
        return False

    def extinguish(self, row: int, col: int) -> None:
        """Set a burning obstacle to extinguished."""
        obs = self.obstacle_map.get((row, col))
        if obs is not None and obs.state == ObstacleState.BURNING:
            obs.state = ObstacleState.EXTINGUISHED

    # ── queries ──────────────────────────────────────────────────────────

    def get_burning(self) -> list[Obstacle]:
        return [o for o in self.obstacle_map.values() if o.state == ObstacleState.BURNING]

    def get_intact(self) -> list[Obstacle]:
        return [o for o in self.obstacle_map.values() if o.state == ObstacleState.INTACT]

    def is_cell_free(self, row: int, col: int) -> bool:
        """True if (row, col) is inside the grid and not occupied."""
        return (0 <= row < cfg.GRID_SIZE
                and 0 <= col < cfg.GRID_SIZE
                and not self.grid[row, col])

    _8_CONNECTED_OFFSETS = [
        (-1,  1),  (0, 1),  (1, 1),
        (-1,  0),           (1, 0),
        (-1, -1), (0, -1), (1, -1),
    ]

    def get_free_neighbors(self, cell: GridCell) -> list[GridCell]:
        """Return all free 8-connected neighbors of cell."""
        r, c = cell
        return [(r+dr, c+dc) for dr, dc in self._8_CONNECTED_OFFSETS if self.is_cell_free(r+dr, c+dc)]

    def is_point_free(self, x: float, y: float) -> bool:
        """True if world point (x, y) is inside bounds and not in an obstacle cell."""
        if not (0 <= x < cfg.FIELD_SIZE and 0 <= y < cfg.FIELD_SIZE):
            return False
        col = int(x // cfg.CELL_SIZE)
        row = int(y // cfg.CELL_SIZE)
        col = min(col, cfg.GRID_SIZE - 1)
        row = min(row, cfg.GRID_SIZE - 1)
        return not self.grid[row, col]

    def is_valid_state(self, geoms: Footprint) -> bool:
        """
        Collision check for the firetruck footprint.

        Each entry is (x_offset, y_offset, shapely_geometry, bounds).
        Bounds are pre-computed by the footprint method to avoid repeated
        Shapely property access.
        Returns True if every geometry is inside bounds and collision-free.
        """
        for ox, oy, g, (minx, miny, maxx, maxy) in geoms:
            bds = (minx + ox, miny + oy, maxx + ox, maxy + oy)

            # boundary check
            if not (bds[0] >= self._bounds[0] and bds[1] >= self._bounds[1]
                    and bds[2] <= self._bounds[2] and bds[3] <= self._bounds[3]):
                return False

            # broad-phase grid check
            c0 = max(0, int(bds[0] // cfg.CELL_SIZE))
            c1 = min(cfg.GRID_SIZE - 1, int(bds[2] // cfg.CELL_SIZE))
            r0 = max(0, int(bds[1] // cfg.CELL_SIZE))
            r1 = min(cfg.GRID_SIZE - 1, int(bds[3] // cfg.CELL_SIZE))
            sub = self.grid[r0:r1 + 1, c0:c1 + 1]
            if not sub.any():
                continue

            # narrow-phase STRtree check
            if ox != 0.0 or oy != 0.0:
                positioned = translate(g, xoff=ox, yoff=oy)
            else:
                positioned = g
            if len(self.collision_tree.query(positioned, predicate="intersects")) > 0:
                return False

        return True

    def is_steady_state(self) -> bool:
        """True when all obstacles are burned or extinguished (no more fire possible)."""
        return all(
            o.state in (ObstacleState.BURNED, ObstacleState.EXTINGUISHED)
            for o in self.obstacle_map.values()
        )

    # ── scoring ──────────────────────────────────────────────────────────

    def compute_scores(self) -> tuple[int, int]:
        """
        Returns (wumpus_score, truck_score).

        Wumpus:  +1 per ignited obstacle, +1 more if fully burned.
        Truck:   +2 per extinguished obstacle.
        """
        w_score = 0
        t_score = 0
        for obs in self.obstacle_map.values():
            if obs.state in (ObstacleState.BURNING, ObstacleState.BURNED):
                w_score += 1
            if obs.state == ObstacleState.BURNED:
                w_score += 1
            if obs.state == ObstacleState.EXTINGUISHED:
                t_score += 2
        return w_score, t_score
