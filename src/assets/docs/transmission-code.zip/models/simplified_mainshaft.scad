primary_shaft_length = 330;


shaft_radius = 18;


gear_thickness = 25;
collar_thickness = 30;
syncro_thickness = 8;

syncro12_radius = 48;
syncro34_radius = 45;

gear1_radius = 65;
gear2_radius = 53;
gear3_radius = 45;
gear_rev_primary = 60;

collar12_radius = 60;
collar34_radius = 60;



module simplified_shaft_assembly() {
    shaft(primary_shaft_length, shaft_radius); 
 
    shaft_offset = 20;
     
    // 3-4 syncro
    translate([0, 0, shaft_offset])
    syncro(syncro34_radius);
    
    // 3-4 collar
    translate([0, 0, shaft_offset + syncro_thickness])
    collar(collar34_radius);
    
    // 3-4 syncro
    translate([0, 0, shaft_offset + syncro_thickness + collar_thickness])
    syncro(syncro34_radius);
    
    
    // 3rd gear
    translate([0, 0, shaft_offset + 2 * syncro_thickness + collar_thickness])
    gear(gear3_radius);
     
    // 2nd gear
    translate([0, 0, shaft_offset + 2 * syncro_thickness + collar_thickness + gear_thickness])
    gear(gear2_radius);
    
    // 1-2 syncro
    translate([0, 0, shaft_offset + 2 * syncro_thickness + collar_thickness + 2 * gear_thickness])
    syncro(syncro12_radius);
    
    // reverse driven gear
    translate([0, 0, shaft_offset + 3 * syncro_thickness + collar_thickness + 2 * gear_thickness])
    straight_gear(gear_rev_primary);
    
    // 1-2 collar
    translate([0, 0, shaft_offset + 3 * syncro_thickness + collar_thickness + 3 * gear_thickness])
    collar(collar12_radius);
    
    // 1-2 syncro
    translate([0, 0, shaft_offset + 3 * syncro_thickness + 2 * collar_thickness + 3 * gear_thickness])
    syncro(syncro12_radius);
 
    // 1st gear
    translate([0, 0, shaft_offset + 4 * syncro_thickness + 2 * collar_thickness + 3 * gear_thickness])
    gear(gear1_radius);

}

module shaft(length, radius) {
    color("gray")
    difference() {
        cylinder(h = length, r = radius);
    }
    // TODO: add splines for fun
}
 
module gear(radius) {
     color([1.0, 1.0, 1.0, 0.95])
        cylinder(h = gear_thickness, r = radius);
}

module straight_gear(radius) {
     color([1.0, 1.0, 1.0, 0.95])
        cylinder(h = gear_thickness, r = radius);
} 




module collar(radius) {
    color([0.6, 0.6, 0.8, 0.85])
    union() {
        cylinder(h = 0.35 * collar_thickness,
                 r1 = radius,
                 r2 = radius);
        translate([0, 0, 0.35 * collar_thickness])
            cylinder(h = 0.3 * collar_thickness,
                     r = radius);
        translate([0, 0, 0.65 * collar_thickness])
            cylinder(h = 0.35 * collar_thickness,
                     r1 = radius,
                     r2 = radius);
    }
}

module syncro(radius) {
    color("#c4ba21")
        cylinder(h = syncro_thickness, r = radius);
}

use <scad/transmission.scad>

// To capture same images, move viewport to:
// FOV: 22.50
// Translation: [ -32.37, 157.17, 24.33 ]
// Rotation: [ 75.30, 0.00, 328.50 ]
// Distance: 624.33


rotate([30, 78, 135])
simplified_shaft_assembly();
//rotate([30, 78, 135])
//primary_shaft_assembly();




