"""
Shared math for the 5-DOF mainshaft pose space.

Used by both the environment (collision transforms) and the planner
(distance metric, interpolation, sampling, steering).

A ShaftPose is (x, y, z, theta, phi):
  - (x, y, z): centroid position in mm
  - theta: polar angle from +Z in [0, pi]
  - phi:   azimuthal angle from +X in [0, 2*pi]
"""

import math
import numpy as np
from dataclasses import dataclass

from transmission.aliases import ShaftPose
from transmission.config import MAINSHAFT_LENGTH


# =============================================================================
# Rotation
# =============================================================================

def rotation_from_spherical(theta: float, phi: float) -> np.ndarray:
    """3x3 rotation matrix mapping local +Z to the direction (theta, phi)."""
    ct, st = math.cos(theta), math.sin(theta)
    cp, sp = math.cos(phi),   math.sin(phi)
    Rz = np.array([[cp, -sp, 0], [sp, cp, 0], [0, 0, 1]])
    Ry = np.array([[ct, 0, st], [0, 1, 0], [-st, 0, ct]])
    return Ry @ Rz


# =============================================================================
# Spherical coordinate <-> direction vector
# =============================================================================

def spherical_to_vec(theta: float, phi: float) -> np.ndarray:
    """Unit direction vector from spherical angles."""
    return np.array([
        math.sin(theta) * math.cos(phi),
        math.sin(theta) * math.sin(phi),
        math.cos(theta),
    ])


def vec_to_spherical(v: np.ndarray) -> tuple[float, float]:
    """Spherical angles from a direction vector (need not be unit length)."""
    v = v / np.linalg.norm(v)
    theta = float(np.arccos(np.clip(v[2], -1.0, 1.0)))
    phi   = float(np.arctan2(v[1], v[0]) % (2 * math.pi))
    return theta, phi


def slerp(v1: np.ndarray, v2: np.ndarray, t: float) -> np.ndarray:
    """Spherical linear interpolation between two direction vectors.

    https://en.wikipedia.org/wiki/Spherical_linear_interpolation#Geometric_slerp
    """
    v1 = v1 / np.linalg.norm(v1)
    v2 = v2 / np.linalg.norm(v2)
    omega = float(np.arccos(np.clip(np.dot(v1, v2), -1.0, 1.0)))
    if omega < 1e-6:
        return v1
    return (np.sin((1 - t) * omega) * v1 + np.sin(t * omega) * v2) / math.sin(omega)


# =============================================================================
# Pose distance and interpolation
# =============================================================================

def pose_distance(p1: ShaftPose, p2: ShaftPose, w_rot: float = MAINSHAFT_LENGTH / 2) -> float:
    """Combined Euclidean position + geodesic orientation distance.

    w_rot scales angular distance (radians) into mm. Default is MAINSHAFT_LENGTH / 2
    (165 mm), so the weight equals the tip radius — a rotation of dθ contributes
    the same as the arc length traced by the shaft tip.

    https://en.wikipedia.org/wiki/Great-circle_distance#Vector_version
    """
    pos_dist = float(np.linalg.norm(np.array(p1[:3]) - np.array(p2[:3])))
    v1, v2   = spherical_to_vec(p1[3], p1[4]), spherical_to_vec(p2[3], p2[4])
    ang_dist = float(np.arccos(np.clip(np.dot(v1, v2), -1.0, 1.0)))
    return pos_dist + w_rot * ang_dist


def interpolate_pose(p1: ShaftPose, p2: ShaftPose, t: float) -> ShaftPose:
    """Linear position + SLERP orientation interpolation at t in [0, 1]."""
    pos = (1.0 - t) * np.array(p1[:3]) + t * np.array(p2[:3])
    v   = slerp(spherical_to_vec(p1[3], p1[4]), spherical_to_vec(p2[3], p2[4]), t)
    theta, phi = vec_to_spherical(v)
    return (float(pos[0]), float(pos[1]), float(pos[2]), theta, phi)


# =============================================================================
# Sampling
# =============================================================================

@dataclass
class PoseBounds:
    """Axis-aligned bounds on the 3-DOF position component of a ShaftPose.

    Orientation (theta, phi) is always sampled uniformly over the full sphere.
    """
    x_range: tuple[float, float] = (-300.0, 300.0)
    y_range: tuple[float, float] = (-300.0, 300.0)
    z_range: tuple[float, float] = (-50.0,  500.0)


def sample_random_pose(bounds: PoseBounds, rng: np.random.Generator) -> ShaftPose:
    """Uniform random pose: position in box, orientation uniform on sphere.

    https://corysimon.github.io/articles/uniformdistn-on-sphere/
    """
    x     = float(rng.uniform(*bounds.x_range))
    y     = float(rng.uniform(*bounds.y_range))
    z     = float(rng.uniform(*bounds.z_range))
    theta = float(np.arccos(rng.uniform(-1.0, 1.0)))
    phi   = float(rng.uniform(0.0, 2 * math.pi))
    return (x, y, z, theta, phi)


# =============================================================================
# Motion
# =============================================================================

def step_toward(from_pose: ShaftPose, to_pose: ShaftPose,
                max_pos_step: float, max_rot_step: float) -> ShaftPose:
    """Advance from from_pose toward to_pose, capped at max_pos_step (mm)
    and max_rot_step (radians) independently."""
    pos_diff = np.array(to_pose[:3]) - np.array(from_pose[:3])
    pos_dist = float(np.linalg.norm(pos_diff))

    v_from = spherical_to_vec(from_pose[3], from_pose[4])
    v_to   = spherical_to_vec(to_pose[3],   to_pose[4])
    ang_dist = float(np.arccos(np.clip(np.dot(v_from, v_to), -1.0, 1.0)))

    if pos_dist < 1e-6 and ang_dist < 1e-6:
        return to_pose

    t_pos = 1.0 if pos_dist < 1e-6 else min(1.0, max_pos_step / pos_dist)
    t_rot = 1.0 if ang_dist < 1e-6 else min(1.0, max_rot_step / ang_dist)
    return interpolate_pose(from_pose, to_pose, min(t_pos, t_rot))
