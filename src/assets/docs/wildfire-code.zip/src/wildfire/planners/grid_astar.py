"""
Grid-based A* planner for the Wumpus.

Operates on the WildfireEnvironment's occupancy grid with 8-connected
movement.  Diagonal moves cost sqrt(2); cardinal moves cost 1.
"""

import math
import heapq

from wildfire.aliases import GridCell, GridPath
from wildfire.environment import WildfireEnvironment


def _heuristic(a: GridCell, b: GridCell) -> float:
    """Octile distance"""
    dr = abs(a[0] - b[0])
    dc = abs(a[1] - b[1])
    return max(dr, dc) + (math.sqrt(2) - 1) * min(dr, dc)



def get_neighbors(env: WildfireEnvironment, cell: GridCell) -> list[tuple[GridCell, float]]:
    """Return free 8-connected neighbors with move costs."""
    return [
        (neighbor, _heuristic(cell, neighbor))
        for neighbor in env.get_free_neighbors(cell)
    ]


def grid_astar(
    env: WildfireEnvironment,
    start: GridCell,
    goal: GridCell,
) -> GridPath | None:
    """
    A* search on the environment grid.

    Args:
        env:   WildfireEnvironment
        start: (row, col) of the start cell.
        goal:  (row, col) of the goal cell.

    Returns:
        Ordered list of (row, col) from start to goal, or None if
        no path exists.
    """
    if start == goal:
        return [start]

    open_set: list[tuple[float, GridCell]] = []
    heapq.heappush(open_set, (0.0, start))

    came_from: dict[GridCell, GridCell] = {}
    g_score: dict[GridCell, float] = {start: 0.0}

    while open_set:
        _, current = heapq.heappop(open_set)

        if current == goal:
            path = [current]
            cur = current
            while cur in came_from:
                cur = came_from[cur]
                path.append(cur)
            path.reverse()
            return path

        for neighbor, cost in get_neighbors(env, current):
            tentative_g = g_score[current] + cost

            if tentative_g < g_score.get(neighbor, float("inf")):
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                f = tentative_g + _heuristic(neighbor, goal)
                heapq.heappush(open_set, (f, neighbor))

    return None
